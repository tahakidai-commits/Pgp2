import { Flashcard } from '../types';

export const INITIAL_FLASHCARDS: Flashcard[] = [
  // ==========================================
  // PARASITOLOGIE - GÉNÉRALITÉS & CYCLES
  // ==========================================
  {
    id: 'fc-para-01',
    subject: 'Parasitologie',
    category: 'Généralités & Cycles',
    front: 'Quelle est la différence fondamentale entre un cycle direct court et un cycle direct long ?',
    back: '• Cycle direct court : Le parasite éliminé est DIRECTEMENT INFESTANT dès son émission (ex: oxyure, kystes d’amibes ou Giardia) -> risque d’auto-infestation immédiate.\n• Cycle direct long : Le parasite doit obligatoirement séjourner dans le milieu extérieur (sol, eau) pour acquérir son pouvoir infestant (maturation/embryonnage ex: Ascaris).',
    mnemonic: 'Court = Directement prêt / Long = Maturation dehors requise',
    sourceReference: 'Fascicule Parasitologie p. 3-4',
    difficulty: 'Facile',
  },
  {
    id: 'fc-para-02',
    subject: 'Parasitologie',
    category: 'Généralités & Cycles',
    front: 'Quelles sont les parasitoses contractées par voie transcutanée active chez l’Homme ?',
    back: '1. Ankylostomiases (Ancylostoma duodenale, Necator americanus) : larves L3 strongyloïdes traversant la peau nue.\n2. Anguillulose (Strongyloides stercoralis) : larves L3 strongyloïdes.\n3. Bilharzioses / Schistosomoses : furcocercaires nageant en eau douce.',
    mnemonic: 'Trio transcutané : Ankylostome, Anguillule, Schistosome',
    sourceReference: 'Fascicule Parasitologie p. 4, 43, 68',
    difficulty: 'Moyen',
  },
  {
    id: 'fc-para-03',
    subject: 'Parasitologie',
    category: 'Généralités & Cycles',
    front: 'Distinguer hôte définitif (HD) et hôte intermédiaire (HI). Donnez le cas particulier du paludisme.',
    back: '• Hôte Définitif (HD) : Héberge la forme adulte ou la phase de reproduction SEXUÉE du parasite.\n• Hôte Intermédiaire (HI) : Héberge les formes larvaires ou la phase de reproduction ASEXUÉE.\n• Cas du Paludisme : L’Homme est l’HI (schizogonie asexuée) et le moustique Anophèle femelle est l’HD (sporogonie sexuée) !',
    mnemonic: 'Sexe = Définitif (Anophèle pour le palu, Homme pour les vers)',
    sourceReference: 'Fascicule Parasitologie p. 3-4',
    difficulty: 'Moyen',
  },
  {
    id: 'fc-para-04',
    subject: 'Parasitologie',
    category: 'Généralités & Cycles',
    front: 'Qu’est-ce que l’action spoliatrice d’un parasite ? Citez l’exemple type.',
    back: 'Le parasite détourne à son profit les nutriments ou fluides de l’hôte :\n• Spoliation sanguine (hématophagie) : Ancylostoma et Necator sucent le sang dans le duodénum (jusqu’à 0,2 mL/ver/jour) -> anémie ferriprive sévère décompensée.\n• Spoliation digestive : Ascaris spolie le chyme intestinal ; Bothriocéphale spolie la vitamine B12 (anémie de Biermer).',
    sourceReference: 'Fascicule Parasitologie p. 5, 43',
    difficulty: 'Facile',
  },

  // ==========================================
  // PARASITOLOGIE - AMIBIASE
  // ==========================================
  {
    id: 'fc-para-05',
    subject: 'Parasitologie',
    category: 'Amibiase',
    front: 'Quelles sont les 3 formes d’Entamoeba histolytica et leurs caractéristiques clés ?',
    back: '1. Forme Végétative Hématophage (FVH) : 20-40 µm, mobile unidirectionnelle par émission d’un pseudopode hyalin, contient des hématies phagocytées. Pathogène invasive (lésions en « bouton de chemise »).\n2. Forme Végétative Minuta (FVM) : 10-20 µm, commensale intraluminale non hématophage.\n3. Kyste mûr : Sphérique de 12-14 µm à 4 NOYAUX (forme de résistance et d’infestation).',
    mnemonic: 'FVH = 20-40 µm + Hématies + Lytique / Kyste = 4 noyaux',
    sourceReference: 'Fascicule Parasitologie p. 12-14',
    difficulty: 'Moyen',
  },
  {
    id: 'fc-para-06',
    subject: 'Parasitologie',
    category: 'Amibiase',
    front: 'Quelle est la stratégie thérapeutique de l’amibiase intestinale aiguë vs hépatique ?',
    back: '• Amibiase intestinale aiguë :\n1) Amoebicide tissulaire : Métronidazole (Flagyl) 1,5-2 g/j pendant 7-10 jours ou Secnidazole 2 g en prise unique.\n2) PUIS obligatoirement amoebicide de contact (Intetrix ou Diloxanide) pour éliminer les kystes résiduels.\n• Amibiase hépatique (abcès amibien chocolat) : Métronidazole IV ou Secnidazole pendant 5 jours consécutifs.',
    mnemonic: 'Toujours Tissulaire d’abord, puis Contact pour les kystes !',
    sourceReference: 'Fascicule Parasitologie p. 16-17',
    difficulty: 'Difficile',
  },

  // ==========================================
  // PARASITOLOGIE - COCCIDIOSES
  // ==========================================
  {
    id: 'fc-para-07',
    subject: 'Parasitologie',
    category: 'Coccidioses',
    front: 'Quelles sont les 3 coccidioses intestinales majeures opportunistes du VIH/SIDA ?',
    back: '1. Cryptosporidiose (Cryptosporidium parvum/hominis) : diarrhée aqueuse sécrétoire profuse (10-20 L/j), cachexie.\n2. Cystoisosporose / Isosporose (Cystoisospora belli) : diarrhée chronique sévère chez VIH+.\n3. Cyclosporose (Cyclospora cayetanensis) : diarrhée aqueuse prolongée.\nCes coccidies ont un cycle direct sans hôte intermédiaire chez l’Homme.',
    mnemonic: 'Les 3 C : Crypto, Cystoisospora, Cyclospora',
    sourceReference: 'Fascicule Parasitologie p. 18-25',
    difficulty: 'Moyen',
  },
  {
    id: 'fc-para-08',
    subject: 'Parasitologie',
    category: 'Coccidioses',
    front: 'Comment différencier au laboratoire les oocystes de Cryptosporidium, Cystoisospora et Cyclospora ?',
    back: '• Cryptosporidium : Très petits (4-6 µm), ronds, Ziehl-Neelsen (+), 4 sporozoïtes NUS sans sporocyste.\n• Cyclospora cayetanensis : 8-10 µm, ronds, AUTOFLUORESCENTS sous UV (bleu 365 nm / vert 450 nm), Ziehl-Neelsen (+).\n• Cystoisospora belli : Grands oocystes ovoïdes (> 30 × 12 µm) contenant 1 ou 2 sporocystes à 4 sporozoïtes chacun.',
    sourceReference: 'Fascicule Parasitologie p. 19-25',
    difficulty: 'Difficile',
  },
  {
    id: 'fc-para-09',
    subject: 'Parasitologie',
    category: 'Coccidioses',
    front: 'Quel est le traitement de référence de la cystoisosporose (isosporose) ?',
    back: 'Le Cotrimoxazole (Triméthoprime + Sulfaméthoxazole / Bactrim) à forte dose pendant 10 jours, suivi d’une prophylaxie secondaire chez le patient séropositif VIH tant que les CD4 < 200/µL.',
    mnemonic: 'Cystoisospora = Cotrimoxazole (Bactrim)',
    sourceReference: 'Fascicule Parasitologie p. 20',
    difficulty: 'Facile',
  },

  // ==========================================
  // PARASITOLOGIE - FLAGELLÉS (GIARDIA & TRICHOMONAS)
  // ==========================================
  {
    id: 'fc-para-10',
    subject: 'Parasitologie',
    category: 'Flagellés',
    front: 'Trichomonas vaginalis possède-t-il une forme kystique ? Quel est son mode de transmission ?',
    back: '• NON ! Trichomonas vaginalis ne forme JAMAIS de kyste. Il existe uniquement sous forme de trophozoïte végétatif flagellé très fragile.\n• Transmission : Strictement vénérienne (IST directe), exceptionnelle par le linge humide très souillé.\n• Clinique femme : Leucorrhées abondantes verdâtres/jaunâtres spumeuses malodorantes + prurit féroce vulvo-vaginal.',
    mnemonic: 'Zéro kyste chez Trichomonas -> IST directe obligatoire !',
    sourceReference: 'Fascicule Parasitologie p. 32-35',
    difficulty: 'Facile',
  },
  {
    id: 'fc-para-11',
    subject: 'Parasitologie',
    category: 'Flagellés',
    front: 'Qu’est-ce que le traitement « minute » de la trichomonose uro-génitale ?',
    back: 'Administration en prise unique de 2 g de Tinidazole (Fasigyne) ou de Secnidazole (Flagentyl).\nImportant : Le traitement simultané du partenaire sexuel est obligatoire pour éviter l’effet « ping-pong ».',
    sourceReference: 'Fascicule Parasitologie p. 35',
    difficulty: 'Facile',
  },
  {
    id: 'fc-para-12',
    subject: 'Parasitologie',
    category: 'Flagellés',
    front: 'Décrire Giardia intestinalis : morphologie trophozoïte vs kyste et mode d’action.',
    back: '• Trophozoïte (10-20 µm) : Forme de cerf-volant avec disque ventral adhérent (« meule »), 2 noyaux symétriques, 4 paires de flagelles. Tapisse le duodéno-jéjunum provoquant malabsorption des graisses (stéatorrhée).\n• Kyste (8-12 µm) : Ovoïde rigide à 4 noyaux et résidus flagellaires, forme de résistance majeure dans l’eau (péril fécal).',
    sourceReference: 'Fascicule Parasitologie p. 26-28',
    difficulty: 'Moyen',
  },

  // ==========================================
  // PARASITOLOGIE - NÉMATODOSES INTESTINALES
  // ==========================================
  {
    id: 'fc-para-13',
    subject: 'Parasitologie',
    category: 'Nématodes',
    front: 'Pourquoi l’oxyure (Enterobius vermicularis) ne se diagnostique-t-il PAS par coprologie classique ?',
    back: 'La femelle adulte ne pond PAS dans la lumière colique ! Elle migre activement la nuit à travers le sphincter anal pour pondre ses œufs sur les plis de la marge anale.\n• Diagnostic de choix : Scotch-test anal de Graham réalisé le matin au réveil avant toute toilette.',
    mnemonic: 'Oxyure = Scotch-test anal au réveil (Graham)',
    sourceReference: 'Fascicule Parasitologie p. 39-40',
    difficulty: 'Facile',
  },
  {
    id: 'fc-para-14',
    subject: 'Parasitologie',
    category: 'Nématodes',
    front: 'Morphologie différentielle des œufs : Ascaris lumbricoides vs Trichuris trichiura.',
    back: '• Ascaris : Ovoïde (60 × 45 µm), marron-brun, coque double épaisse avec coque externe mamelonnée/bosselée, masse centrale granuleuse.\n• Trichuris (trichocéphale) : Forme typique en « citron » ou en « baril » (50 × 22 µm), brune, avec un BOUCHON MUQUEUX saillant à chaque pôle.',
    mnemonic: 'Trichuris = Citron à deux bouchons muqueux',
    sourceReference: 'Fascicule Parasitologie p. 37, 42',
    difficulty: 'Moyen',
  },
  {
    id: 'fc-para-15',
    subject: 'Parasitologie',
    category: 'Nématodes',
    front: 'Quel nématode intestinal est caractérisé par une femelle parthénogénétique et un cycle d’auto-infestation ?',
    back: 'Strongyloides stercoralis (l’Anguillule) !\n• Seule la femelle parthénogénétique vit enchâssée dans la muqueuse duodénale.\n• Les larves rhabditoïdes émises peuvent muer sur place en larves strongyloïdes L3 infestantes -> auto-infestation interne (hyperinfestation gravissime chez l’immunodéprimé sous corticoïdes).',
    mnemonic: 'Anguillule = Parthénogenèse + Auto-infestation maligne',
    sourceReference: 'Fascicule Parasitologie p. 45-47',
    difficulty: 'Difficile',
  },

  // ==========================================
  // PARASITOLOGIE - SCHISTOSOMOSES (BILHARZIOSES)
  // ==========================================
  {
    id: 'fc-para-16',
    subject: 'Parasitologie',
    category: 'Bilharzioses',
    front: 'Différencier Schistosoma haematobium et Schistosoma mansoni (œufs, localisation, vecteur, clinique).',
    back: '• S. haematobium : Éperon TERMINAL, excrété dans les URINES, hôte intermédiaire mollusque bulin (Bulinus), plexus vésical -> hématurie terminale, cancérisation de la vessie.\n• S. mansoni : Éperon LATÉRAL très visible, excrété dans les SELLES, hôte intermédiaire planorbe (Biomphalaria), plexus mésentérique -> dysenterie bilharzienne, hépatosplénomégalie, hypertension portale.',
    mnemonic: 'Haematobium = Terminal (Pipi) / Mansoni = Latéral (Caca)',
    sourceReference: 'Fascicule Parasitologie p. 67-71',
    difficulty: 'Moyen',
  },
  {
    id: 'fc-para-17',
    subject: 'Parasitologie',
    category: 'Bilharzioses',
    front: 'Quel est le traitement universel de toutes les schistosomoses et quelle est sa posologie ?',
    back: 'Le Praziquantel (Biltricide) à la dose unique de 40 mg/kg en une seule prise au cours d’un repas. Il est actif sur toutes les espèces (S. haematobium, S. mansoni, S. intercalatum, S. japonicum, S. mekongi).',
    mnemonic: 'Praziquantel 40 mg/kg prise unique',
    sourceReference: 'Fascicule Parasitologie p. 71',
    difficulty: 'Facile',
  },
  {
    id: 'fc-para-18',
    subject: 'Parasitologie',
    category: 'Bilharzioses',
    front: 'Quelles espèces de schistosomes sont endémiques en Côte d’Ivoire ? Piège à éviter !',
    back: '• Endémiques en Côte d’Ivoire : Schistosoma haematobium et Schistosoma mansoni.\n• Pièges fréquents de concours :\n- S. mekongi sévit en Asie (Mékong), JAMAIS en Côte d’Ivoire.\n- S. bovis est un parasite du bétail qui n’infeste pas l’Homme.',
    sourceReference: 'Fascicule Parasitologie p. 67-68',
    difficulty: 'Moyen',
  },

  // ==========================================
  // PARASITOLOGIE - FILARIOSES & DRACUNCULOSE
  // ==========================================
  {
    id: 'fc-para-19',
    subject: 'Parasitologie',
    category: 'Filarioses',
    front: 'Onchocerca volvulus : Quel est son vecteur, sa lésion oculaire et où prélève-t-on la BCE ?',
    back: '• Vecteur : La Simulie femelle (Simulium damnosum), moucheron piquant près des cours d’eau rapides.\n• Clinique : Onchocercose (« Cécité des rivières ») par kératite sclérosante et choriorétinite ; gale filarienne cutanée prurigineuse.\n• Diagnostic : Biopsie Cutanée Exsangue (BCE) prélevée à la crête iliaque chez l’Africain (à l’omoplate chez l’Américain).',
    sourceReference: 'Fascicule Parasitologie p. 55-59',
    difficulty: 'Difficile',
  },
  {
    id: 'fc-para-20',
    subject: 'Parasitologie',
    category: 'Filarioses',
    front: 'Quelle est la périodicité sanguine de Loa loa et de Wuchereria bancrofti ?',
    back: '• Loa loa : Périodicité DIURNE stricte (pic entre 10h et 15h, concordant avec l’activité du taon Chrysops).\n• Wuchereria bancrofti : Périodicité NOCTURNE stricte (pic entre 22h et 02h, concordant avec l’activité des moustiques Culex/Anopheles).',
    mnemonic: 'Loa = Lumière (Jour/Chrysops) / Bancrofti = Nuit (Culex)',
    sourceReference: 'Fascicule Parasitologie p. 55, 63-65',
    difficulty: 'Moyen',
  },
  {
    id: 'fc-para-21',
    subject: 'Parasitologie',
    category: 'Dracunculose',
    front: 'Comment l’Homme se contamine-t-il par Dracunculus medinensis (ver de Guinée) ?',
    back: 'Par ingestion d’EAU DOUCE DE BOISSON contenant des petits crustacés copépodes (Cyclops) parasités par la larve L3 infestante.\nLe cycle est DIXÈNE (2 hôtes : Cyclops = hôte intermédiaire passif, et Homme = hôte définitif).',
    mnemonic: 'Cyclops avalé dans l’eau = Ver de Guinée dans la jambe',
    sourceReference: 'Fascicule Parasitologie p. 51-53',
    difficulty: 'Facile',
  },

  // ==========================================
  // PARASITOLOGIE - CESTODOSES & GALE
  // ==========================================
  {
    id: 'fc-para-22',
    subject: 'Parasitologie',
    category: 'Cestodoses',
    front: 'Quelle est la différence fondamentale entre Téniasis et Neurocysticercose ?',
    back: '• Téniasis (adulte dans l’intestin) : Contamination par ingestion de viande de bœuf (T. saginata) ou de porc (T. solium) mal cuite contenant des CYSTICERQUES.\n• Neurocysticercose (larve dans le cerveau) : Contamination par ingestion d’ŒUFS de Taenia solium (eau, mains sales). L’Homme devient hôte intermédiaire accidentel. Cause majeure de crises convulsives épileptiques.',
    mnemonic: 'Cysticerque mangé = Ver solitaire / Œuf de T. solium mangé = Kystes au cerveau !',
    sourceReference: 'Fascicule Parasitologie p. 74-76',
    difficulty: 'Difficile',
  },
  {
    id: 'fc-para-23',
    subject: 'Parasitologie',
    category: 'Scabiose / Gale',
    front: 'Sarcoptes scabiei : Caractéristiques de l’acarien, signes cliniques et traitement complet.',
    back: '• Parasite : Acarien monoxène strictement humain. Femelle creuse un sillon intra-épidermique sous la couche cornée.\n• Clinique : Prurit féroce à recrudescence nocturne (épargnant le visage), sillons scabieux terminés par une vésicule perlée (espaces interdigitaux, poignets, organes génitaux).\n• Traitement : Ivermectine 200 µg/kg PO ou Benzoate de benzyle en badigeon cutané + pulvérisation d’acaricide (pyréthrinoïdes) sur la literie et vêtements.',
    mnemonic: 'Sillon + Vésicule perlée + Prurit nocturne + Ivermectine 200 µg/kg',
    sourceReference: 'Fascicule Parasitologie p. 77-80',
    difficulty: 'Moyen',
  },
  {
    id: 'fc-para-24',
    subject: 'Parasitologie',
    category: 'Larva Migrans',
    front: 'Distinguer Larva migrans cutanée (larbish) et Larva migrans viscérale (toxocarose).',
    back: '• Larva migrans cutanée (LMC / larbish) : Due aux ankylostomes de chiens/chats (Ancylostoma brasiliensis/caninum). Pénétration transcutanée sur plage de sable, cordon érythémateux serpigineux très prurigineux.\n• Larva migrans viscérale (LMV) : Due à Toxocara canis/cati. Ingestion d’œufs de chien. Impasse parasitaire, grande hyperéosinophilie (syndrome de Löffler sévère), diagnostic sérologique (ELISA/Western-Blot).',
    sourceReference: 'Fascicule Parasitologie p. 81-84',
    difficulty: 'Moyen',
  },

  // ==========================================
  // GALÉNIQUE - MATIÈRES PREMIÈRES & EXCIPIENTS
  // ==========================================
  {
    id: 'fc-gale-01',
    subject: 'Galénique',
    category: 'Excipients',
    front: 'Qu’est-ce qu’un Excipient à Effet Notoire (EEN) ? Citez 3 exemples majeurs.',
    back: 'Un excipient dont la présence peut provoquer des effets indésirables ou réactions allergiques chez certains patients fragiles, nécessitant une mention obligatoire sur la notice et l’emballage.\nExemples :\n1. Lactose (intolérance au galactose/lactose)\n2. Huile d’arachide ou de soja (choc anaphylactique)\n3. Aspartam (source de phénylalanine, contre-indiqué dans la phénylcétonurie)\n4. Éthanol (enfants, conducteurs, sevrage alcoolique).',
    sourceReference: 'Support Pharmacie Galénique PGP1 p. 6-8',
    difficulty: 'Facile',
  },
  {
    id: 'fc-gale-02',
    subject: 'Galénique',
    category: 'Excipients',
    front: 'Comment varie l’état physique des Polyéthylèneglycols (PEG / Macrogols) selon leur masse molaire ?',
    back: '• PEG < 600 g/mol (PEG 200, 300, 400, 600) : Liquides limpides et visqueux à température ambiante.\n• PEG entre 600 et 800 g/mol : Pâteux (aspect semi-solide de vaseline).\n• PEG > 800 g/mol (PEG 1000, 1500, 4000, 6000) : Solides cireux ou paillettes blanches solubles dans l’eau.',
    mnemonic: 'Moins de 600 = Liquide / Plus de 800 = Solide cireux',
    sourceReference: 'Support Pharmacie Galénique PGP1 p. 14',
    difficulty: 'Moyen',
  },
  {
    id: 'fc-gale-03',
    subject: 'Galénique',
    category: 'Opérations',
    front: 'Quels sont les paramètres de référence de la stérilisation à la vapeur d’eau (Autoclave) ?',
    back: 'Stérilisation par chaleur humide sous pression :\n• Température standard : 121 °C (ou 134 °C pour le matériel chirurgical/prions).\n• Pression : 2 bars de vapeur d’eau saturée.\n• Durée : 15 à 20 minutes.\nC’est la méthode de référence pour les solutés injectables aqueux thermostables.',
    mnemonic: 'Autoclave classique = 121 °C / 15-20 min / 2 bars',
    sourceReference: 'Support Galénique Opérations p. 28-30',
    difficulty: 'Facile',
  },
  {
    id: 'fc-gale-04',
    subject: 'Galénique',
    category: 'Formulation',
    front: 'Quel polymère dérivé de cellulose est utilisé pour fabriquer des comprimés gastro-résistants ?',
    back: 'L’Acétophtalate de cellulose (CAP) ou l’Hypromellose acétate succinate (HPMCAS) !\nLeur solubilité dépend du pH : insolubles en milieu acide stomacal (pH 1-3), ils s’ionisent et se dissolvent au pH neutre ou alcalin du duodénum (pH > 6).',
    sourceReference: 'Support Pharmacie Galénique PGP1 p. 22',
    difficulty: 'Moyen',
  },

  // ==========================================
  // TOXICOLOGIE - CLINIQUE & ANTIDOTES
  // ==========================================
  {
    id: 'fc-toxi-01',
    subject: 'Toxicologie',
    category: 'Mécanismes & Antidotes',
    front: 'Toxicité du Paracétamol : Quel métabolite toxique est formé et quel est l’antidote spécifique ?',
    back: '• Métabolite toxique : Le N-acétyl-p-benzoquinone imine (NAPQI), produit par le cytochrome CYP2E1 lors de la saturation des voies de glucurono- et sulfoconjugaison.\n• Mécanisme : Le NAPQI épuise les réserves de glutathion hépatique et provoque une nécrose hépatocellulaire centrolobulaire cytolytique massive.\n• Antidote spécifique : La N-Acétylcystéine (NAC), précurseur de synthèse du glutathion qui neutralise le NAPQI (protocole IV ou per os).',
    mnemonic: 'Paracétamol saturé -> NAPQI toxique -> Antidote = N-Acétylcystéine',
    sourceReference: 'Support Toxicologie Pr TIGORI p. 18-20',
    difficulty: 'Facile',
  },
  {
    id: 'fc-toxi-02',
    subject: 'Toxicologie',
    category: 'Mécanismes & Antidotes',
    front: 'Citez 4 couples Toxique / Antidote d’urgence majeurs à connaître par cœur.',
    back: '1. Opioïdes (Morphine, Fentanyl, Héroïne) <-> NALOXONE (Narcan)\n2. Benzodiazépines <-> FLUMAZÉNIL (Anexate)\n3. Insecticides organophosphorés <-> ATROPINE + PRALIDOXIME\n4. Monoxyde de carbone (CO) <-> OXYGÉNOTHÉRAPIE normobare ou hyperbare\n5. Cyanures <-> HYDROXOCOBALAMINE (Cyanokit)',
    sourceReference: 'Support Toxicologie Pr TIGORI p. 28-32',
    difficulty: 'Moyen',
  },
  {
    id: 'fc-toxi-03',
    subject: 'Toxicologie',
    category: 'Toxicologie Environnementale',
    front: 'Quels étaient les toxiques majeurs incriminés dans le drame du Probo Koala (Abidjan 2006) ?',
    back: 'Les résidus de lavage de naphta acide déversés contenaient principalement :\n1. Sulfure d’hydrogène (H2S) : gaz asphyxiant cellulaire violent à odeur d’œuf pourri bloquant la cytochrome c oxydase mitochondriale.\n2. Mercaptans (méthyl- et éthyl-mercaptans) : composés organosulfurés hautement volatils et irritants des muqueuses respiratoires et oculaires.\n3. Hydrocarbures aromatiques et phénols.',
    sourceReference: 'Support Toxicologie Pr TIGORI p. 33-35',
    difficulty: 'Moyen',
  },

  // ==========================================
  // PHARMACOLOGIE & GESTION LOGISTIQUE
  // ==========================================
  {
    id: 'fc-phar-01',
    subject: 'Pharmacologie',
    category: 'Pharmacocinétique',
    front: 'Définir la biodisponibilité (F) et l’effet de premier passage hépatique (EPPH).',
    back: '• Biodisponibilité (F) : Fraction de la dose administrée qui atteint la circulation sanguine générale sous forme inchangée, ainsi que la vitesse à laquelle ce processus se produit (100% par voie IV).\n• EPPH : Dégradation ou métabolisation partielle du médicament par les enzymes de la paroi intestinale et du foie avant d’atteindre la circulation systémique lors de l’absorption per os.',
    sourceReference: 'Support Pharmacologie Générale p. 12',
    difficulty: 'Facile',
  },
  {
    id: 'fc-logi-01',
    subject: 'Gestion Logistique',
    category: 'Chaîne d’approvisionnement',
    front: 'Quelle est la règle FEFO vs FIFO dans la gestion des stocks de produits de santé ?',
    back: '• FEFO (First Expired, First Out / Premier Périmé, Premier Sorti) : RÈGLE D’OR en pharmacie. Les médicaments dont la date de péremption est la plus proche sont toujours dispensés en premier, quelle que soit leur date de livraison.\n• FIFO (First In, First Out / Premier Entré, Premier Sorti) : S’applique aux consommables sans date de péremption critique.',
    mnemonic: 'Médicaments = toujours FEFO (priorité à la péremption la plus courte)',
    sourceReference: 'Support Logistique des Produits de Santé p. 15',
    difficulty: 'Facile',
  },
  {
    id: 'fc-logi-02',
    subject: 'Gestion Logistique',
    category: 'Chaîne de froid',
    front: 'Quelles sont les plages de température réglementaires pour les produits thermosensibles ?',
    back: '• Produits froids (+2 °C à +8 °C) : Insulines, vaccins, produits sanguins, anticorps monoclonaux, réactifs d’analyses.\n• Produits à température ambiante contrôlée (+15 °C à +25 °C) : Médicaments standards à l’abri de l’humidité et du rayonnement direct.\n• Congélation (-20 °C ou -70 °C) : Certains vaccins à ARN messager ou dérivés stables congelés.',
    sourceReference: 'Support Logistique des Produits de Santé p. 22',
    difficulty: 'Facile',
  },
];

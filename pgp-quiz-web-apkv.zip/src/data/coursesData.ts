import { Course } from '../types';
import { COURSE_PARASITOLOGIE } from './courseParasitologie';

export const COURSES_DATA: Course[] = [
  COURSE_PARASITOLOGIE,
  {
    id: 'cours-operations-pharmacie',
    title: 'Opération Pharmacie & Calculs Galéniques',
    subject: 'Galénique',
    badge: '53 pages de cours',
    author: 'Enseignement de Pharmacie Galénique PGP1',
    pageCount: 53,
    iconName: 'FlaskConical',
    colorScheme: {
      primary: '#0D9488',
      bg: '#F0FDFA',
      light: '#CCFBF1',
      border: '#99F6E4',
    },
    summary: 'Guide exhaustif des opérations pharmaceutiques fondamentales (dessiccation, pulvérisation, tamisage, mélanges, dissolution, séparations, stérilisation) et des calculs officinaux et hospitaliers (débits de perfusion, dilutions, posologies et formules galéniques).',
    learningObjectives: [
      'Maîtriser les 7 opérations pharmaceutiques fondamentales et le fonctionnement des appareils officinaux et industriels.',
      'Savoir identifier et prévenir les incompatibilités chimiques et physiques lors de la réalisation des mélanges.',
      'Différencier les procédés de stérilisation (chaleur sèche, chaleur humide, radiations, gaz, filtration stérilisante).',
      'Calculer précisément les débits de perfusion en gouttes/min, les temps de passage et les dilutions C1V1=C2V2.',
      'Calculer les doses pédiatriques par rapport au poids (mg/kg), à l’âge et à la surface corporelle (mg/m²).'
    ],
    linkedQuizIds: [70, 60, 61],
    chapters: [
      {
        id: 'op-ch1-dessiccation',
        number: 1,
        title: 'Chapitre 1 : Les Opérations Pharmaceutiques',
        description: 'Les méthodes de transformation physique et galénique des matières premières jusqu’à la forme finie.',
        sections: [
          {
            id: 'sec-dessiccation',
            title: '1. La Dessiccation (Séchage)',
            subtitle: 'Élimination totale ou partielle de l’eau ou solvant volatil',
            content: `La dessiccation a pour but d’enlever totalement ou partiellement l’eau contenue dans un produit solide, ou d'éliminer toute substance volatile présente dans un corps non volatil.

**Intérêts majeurs :**
- Concentration des principes actifs dans le produit desséché.
- Manipulation, fragmentation et dosages plus aisés pour les poudres sèches.
- Meilleure conservation : l’eau favorise le développement des micro-organismes, leur dégradation enzymatique et l’oxydation.

**Méthodes utilisées :**
1. **Séchage à l’air libre :** Plantes dont les principes actifs ne sont pas fragiles, hangars bien aérés sur claies en couches minces. Méthode lente avec risque de pollution par les insectes.
2. **Séchage à l’air chaud :**
   - *Séchoirs discontinus :* Étuves à température constante sur plateaux superposés.
   - *Séchoirs à lit fluidisé :* Le récipient à fond perforé est traversé de bas en haut par un courant d'air chaud provoquant un brassage continu jusqu'à dessiccation complète.
   - *Séchoirs continus (tunnels à contre-courant) :* La substance humide avance en continu sur wagonnets ou bandes roulantes tandis que l'air chaud circule en sens inverse. Très utilisé pour les plantes à grande échelle.
3. **Séchage sous vide :** Abaissement de la pression permettant d'opérer à basse température pour les produits thermolabiles. Utilise des armoires à vide à plateaux chauffés par fluide chaud ou résistances/infrarouges.
4. **Séchage en couche mince sur cylindre(s) :** Cylindres chauffés intérieurement trempant dans le liquide. La rotation entraîne un film liquide qui se dessèche au cours du cycle (ex : lait en poudre).
5. **Nébulisation (atomisation) :** Dispersion de la substance sous forme de brouillard très fin (gouttelettes) au sein d'un courant d'air très chaud (150 à 200°C). L'eau s'évapore instantanément pour donner une poudre très légère (nébulisât). Idéal pour les substances fragiles et sensibles à la chaleur grâce à la brièveté du contact.
6. **Lyophilisation (cryodessiccation) :** Dessiccation par sublimation de la glace de solutions ou tissus préalablement solidifiés par congélation. L'eau congelée passe directement de l'état solide à l'état gazeux (vapeur) sans passer par l'état liquide sous vide poussé.

**Les 3 étapes de la lyophilisation :**
1. *Congélation rapide :* Évite la dégradation du produit.
2. *Sublimation :* Passage direct solide -> gaz sous vide.
3. *Condensation :* Piégeage des dernières molécules d'eau sur le système réfrigérant sous forme de givre.
*Applications :* Plasma humain, fractions sanguines, antibiotiques, vaccins vivants (BCG), ferments, extraits d'organes (opothérapie).`,
            keyTakeaways: [
              'La lyophilisation = congélation -> sublimation sous vide -> condensation.',
              'La nébulisation produit des poudres extrêmement légères à dissolution rapide.',
              'L’eau résiduelle est l’ennemie n°1 de la stabilité galénique (hydrolyse, microbes).'
            ]
          },
          {
            id: 'sec-pulverisation',
            title: '2. La Pulvérisation et le Broyage',
            subtitle: 'Réduction mécanique d’un solide en particules de granulométrie définie',
            content: `La pulvérisation consiste à réduire un solide en petites particules pour faciliter la manipulation, accroître la vitesse de dissolution et améliorer la biodisponibilité (ex : formes orales micronisées).

**Étapes préparatoires :**
- **Mondation :** Débarrasser les matières premières de toutes les parties inutiles (ex : mondation des amandes = élimination de la pellicule externe, criblage des graines).
- **Division grossière :** Concassage aux marteaux-pillons, découpe à la râpe ou section au couteau (racines friables, camphre).

**Mécanismes de division mécanique :**
- Compression
- Percussion au choc
- Abrasion / frottement
- Cisaillement
- Arrachement
*Règle :* Pour les substances très dures -> compression et percussion ; pour les friables -> abrasion et cisaillement ; pour les substances molles -> arrachement.

**Appareils industriels :**
- *Broyeurs à meules :* Verticales ou horizontales (ancêtre meules à céréales).
- *Broyeurs à cylindres :* Deux cylindres lisses ou cannelés tournant en sens inverse à écartement réglable (ex: poudres dentifrices).
- *Broyeurs à couteaux :* Pour les plantes fraîches ou sèches avant extraction.
- *Broyeurs à marteaux et percuteurs :* Bras métalliques ou broches tournant à très grande vitesse.
- *Broyeurs à boulets & broyeur planétaire :* Récipients métalliques ou porcelaine contenant des boulets de 1 à 10 cm. Le broyeur planétaire utilise la force centrifuge pour obtenir des poudres micrométriques pour produits très durs.
- *Microniseurs à air comprimé (jets d'air) :* Les particules se percutent violemment entre elles dans un tourbillon d'air. Aucun échauffement : idéal pour substances thermosensibles.`,
            keyTakeaways: [
              'Substances dures = compression et percussion.',
              'Les microniseurs à jet d’air évitent tout échauffement thermique.',
              'La mondation retire les parties inertes avant le broyage.'
            ]
          },
          {
            id: 'sec-tamisage',
            title: '3. Le Tamisage et la Granulométrie',
            subtitle: 'Contrôle et séparation selon la dimension des mailles',
            content: `Après broyage, la poudre doit être calibrée par tamisage à travers un tissage de fils métalliques rigides.

- **Numéro de tamis :** Dimension de la maille exprimée en micromètres (d) selon la Pharmacopée (de 38 µm à 11,2 mm).
- **Rappel dimensionnel :** 1 micromètre (µm) = 10⁻⁶ m = 0,001 mm.

**Classification des poudres selon la finesse :**
- Poudre grossière
- Poudre modérément fine
- Poudre fine
- Poudre très fine

**Méthodes d'analyse granulométrique :**
1. *Tamisage en colonne vibrante :* Succession de tamis de maille décroissante, pesée de chaque fraction retenue et tracé de l'histogramme de fréquence.
2. *Microscopie :* Micromètre oculaire ou projection vidéo automatisée.
3. *Compteur de particules (Coulter) :* Mesure de la variation de résistance électrique lors du passage des particules dans un micro-orifice.`,
            keyTakeaways: [
              'Tamis 38 µm = poudre très fine ; tamis > 1 mm = poudre grossière.',
              'L’histogramme granulométrique garantit l’homogénéité du mélange.'
            ]
          },
          {
            id: 'sec-melanges',
            title: '4. Mélanges, Dispersions & Incompatibilités',
            subtitle: 'Association homogène et prévention des interactions négatives',
            content: `Le mélange consiste en l'association la plus homogène possible de plusieurs substances (solides, liquides ou gazeuses). Chaque fraction prélevée au hasard doit contenir tous les constituants dans les mêmes proportions.

**Mélange des poudres :**
- Nécessite des poudres de densité et de granulométrie voisines pour éviter le démélage par gravité.
- Si proportions inégales : procéder par dilution géométrique (mélanger d'abord le principe actif minoritaire avec une quantité égale d'excipient, puis doubler progressivement).

**Appareils de mélange :**
- *À cuve mobile :* Récipients tournants cylindriques, cubiques ou en V (remplissage max à 50% du volume pour permettre le brassage).
- *À cuve fixe :* Hermétiques, agitation par bras, socs de charrue tourbillonnaires ou vis hélicoïdale.

**Incompatibilités Pharmaceutiques majeures :**
1. **Chimiques :**
   - *Coloration anormale*
   - *Précipitation :* Benzoate de sodium + acide -> acide benzoïque insoluble ; Benzoate de sodium + chlorure de calcium -> sels de calcium insolubles.
   - *Dégagement gazeux (CO2) :* Bicarbonate de sodium + acide citrique ou glycémie boratée.
   - *Mélanges explosifs :* Oxydants puissants (permanganate de potassium, eau oxygénée) + réducteurs organiques (alcool, glycérine, sucre, amidon).
   - *Formation de corps toxique :* Eau de laurier cerise + codéine base -> formation de cyanure de morphine !
2. **Physiques :**
   - *Substances hygroscopiques / déliquescentes :* Nébulisâts, bromures et iodures de calcium ou magnésium.
   - *Mélanges eutectiques pâteux ou liquides :* Camphre + chloral, Camphre + menthol, Résorcine + menthol.
   - *Insolubilité :* Phénobarbital insoluble dans l'eau (doit être remplacé par le phénobarbital sodique à 90% de base).
   - *Non miscibilité :* Bromoforme + eau, Huiles essentielles + eau.
   - *Rupture d'états colloïdaux :* Argyrol + sérum physiologique (précipitation immédiate de chlorure d'argent).`,
            keyTable: {
              headers: ['État physique des produits', 'Opération de mélange', 'Préparation obtenue'],
              rows: [
                ['Liquide + liquide miscible', 'Dissolution ou mélange', 'Solution vraie'],
                ['Liquide + liquide non miscible', 'Dispersion avec émulsifiant', 'Émulsion (H/E ou E/H)'],
                ['Liquide + solide faible quantité soluble', 'Dissolution', 'Solution limpide'],
                ['Liquide + solide grande quantité insoluble', 'Dispersion', 'Suspension'],
                ['Solide + liquide faible quantité', 'Malaxage', 'Pâte / Pommade'],
                ['Solide + solide', 'Mélange de poudres', 'Poudre composée / Gélule']
              ]
            }
          },
          {
            id: 'sec-dissolution-separation',
            title: '5. Dissolution & Opérations de Séparation',
            subtitle: 'Dissolution extractive, filtration, décantation, distillation, expression',
            content: `**Dissolution simple :**
Division d'une substance à l'état moléculaire au sein d'un liquide. Le solvant dissout le soluté sans altérer la limpidité.
- *Facteurs favorisants :* Température (augmente Cs), agitation, surface de contact (poudres fines), pH adapté.
- *Dissolution par intermédiaire :*
  - Chimique : Acide acétylsalicylique insoluble + NaOH -> Aspirine soluble (sel de Na).
  - Physique : Caféine peu soluble + Benzoate de sodium ou Salicylate de sodium.

**Dissolution extractive des drogues végétales :**
- **Macération :** Contact drogue + eau potable à froid (20°C) pendant 30 min à 4h -> produit = *macéré* (résidu = *marc*).
- **Digestion :** Contact drogue + eau à température tiède (25°C à < ébullition) pendant 1h à 15h -> *digesté*.
- **Décoction :** Maintien de l'ébullition pendant quelques minutes à plusieurs heures -> *décocté*.
- **Infusion :** Eau bouillante versée sur la drogue puis laissée en contact -> *infusé* (macération à chaud courte).
- **Lixiviation (percolation) :** Solvant froid traversant lentement de haut en bas la drogue pulvérisée -> *percolât*.

**Opérations de séparation mécanique :**
- **Filtration :** Séparation solide/liquide sur réseau poreux (papier filtre, Büchner, membranes filtrantes acétate de cellulose). Débit négativement influencé par la viscosité et le colmatage.
- **Décantation :** Séparation par gravité selon la différence de densité des phases non miscibles.
- **Centrifugation :** Accélération de la séparation par force centrifuge (ex : ultracentrifugation du sérum sanguin).
- **Expression :** Extraction de liquide sous presse mécanique (huiles d'olive, d'agrumes, teintures-mères homéopathiques).
- **Distillation :** Vaporisation par ébullition suivie de condensation des vapeurs dans un serpentin réfrigérant.
  - Distillat alcoolique = *alcoolat*.
  - Distillat hydrique = *hydrolat* ou eau distillée aromatique.`,
            keyTakeaways: [
              'Infusion = eau bouillante versée sur la plante.',
              'Décoction = maintien à ébullition prolongé.',
              'Percolation / lixiviation = passage vertical continu du solvant de haut en bas.'
            ]
          },
          {
            id: 'sec-sterilisation',
            title: '6. La Stérilisation Pharmaceutique',
            subtitle: 'Procédés thermiques, rayonnements, gaz et filtration',
            content: `La stérilisation détruit ou élimine tous les micro-organismes vivants (bactéries, virus, champignons) sous forme végétative ou sporulée.

**Règle biologique fondamentale :**
La forme végétative est active mais vulnérable. La **spore bactérienne** est la forme de résistance et de protection. Si un procédé détruit la spore, toutes les formes végétatives sont éliminées. Le spore sert donc de témoin de stérilisation.

**Méthodes de stérilisation :**
1. **Chaleur sèche :**
   - Étuve ou four Poupinel à **180°C pendant 30 minutes** (ou 160°C pendant 2 heures).
   - Réservée aux objets métalliques (instruments chirurgicaux) et en verre résistant.
2. **Chaleur humide (Vapeur d’eau sous pression) :**
   - **Autoclave :** Porter l'eau à ébullition sous pression (> 100°C : classiquement **121°C pendant 15 à 20 min** ou 134°C).
   - Plus efficace et opérant à plus basse température que la chaleur sèche grâce à la pénétration de la vapeur saturée.
3. **Rayonnements ionisants (Bêta et Gamma) :**
   - Utilisés à froid pour stériliser le matériel chirurgical à usage unique sous emballage étanche définitif (seringues, compresses, fils de suture).
4. **Rayonnements ultra-violets (UV) :**
   - Faible pénétration (stoppés par le verre). Utilisés uniquement pour décontaminer l'air et les surfaces des enceintes stériles.
5. **Antiseptiques gazeux :**
   - **Oxyde d’éthylène :** Gaz hautement bactéricide pour matériaux ne supportant pas l'autoclave (plastiques, cathéters, caoutchouc). Manipulation très encadrée car toxique et explosif.
   - **Formaldéhyde (formol) :** Désinfection de surface des blocs opératoires.
6. **Filtration stérilisante :**
   - Passage des solutions thermosensibles à travers des membranes à porosité nominale de **0,22 micromètre (µm)** retenant les bactéries. Doit être suivie d'une répartition aseptique immédiate.`,
            keyTakeaways: [
              'Poupinel (chaleur sèche) : 180°C pendant 30 min.',
              'Autoclave (chaleur humide) : 121°C sous pression de vapeur.',
              'Membrane stérilisante : seuil de coupure absolu à 0,22 µm.'
            ]
          }
        ]
      },
      {
        id: 'op-ch2-calculs',
        number: 2,
        title: 'Chapitre 2 : Calculs Pharmaceutiques & Posologies',
        description: 'Unités de mesure, calculs de débits de perfusion, dilutions et posologies médicamenteuses.',
        sections: [
          {
            id: 'sec-mesures-masses-volumes',
            title: '1. Unités de Mesure & Équivalences Pratiques',
            subtitle: 'Masses, balances et mesures usuelles de cuillères et compte-gouttes',
            content: `**Balances de précision en pharmacie :**
- *Balance Roberval :* 20 g à 10 kg.
- *Trébuchet :* 5 cg (0,05 g) à 200 g (sensibilité au 1/10 mg pour pesées officinales fines).
- *Qualités métrologiques :*
  - **Portée :** Masse maximale supportable sans déformation.
  - **Sensibilité :** Plus petite masse qui modifie l'équilibre de façon perceptible.
  - **Justesse :** Concordance entre valeur mesurée et valeur vraie.
  - **Fidélité / Reproductibilité :** Répétabilité des mesures successives identiques.

**Équivalences usuelles des cuillères médicales :**
- **1 Cuillerée à café (c à c)** = 5 mL = 5 g d'eau pure = 4,5 g d'huile = 6,5 g de sirop.
- **1 Cuillerée à dessert (c à d)** = 10 mL = 10 g d'eau pure = 9 g d'huile = 13 g de sirop.
- **1 Cuillerée à soupe (c à s)** = 15 mL = 15 g d'eau pure = 13,5 g d'huile = 19 g de sirop.

**Compte-gouttes normalisé de la Pharmacopée (à 20°C) :**
- **20 gouttes d’eau distillée** = 1 mL = 1 g.
- **40 gouttes d’alcool / solution alcoolique** = 1 g.
*Règle d'utilisation :* Tenir le compte-gouttes parfaitement à la verticale, faire couler lentement les gouttes une à une.`,
            keyTakeaways: [
              '1 c à café = 5 mL ; 1 c à dessert = 10 mL ; 1 c à soupe = 15 mL.',
              '20 gouttes d’eau = 1 mL = 1 g ; 40 gouttes de solution alcoolique = 1 g.',
              'Trébuchet = balance de précision pour pesées fines (5 cg à 200 g).'
            ]
          },
          {
            id: 'sec-calcul-debit-perfusion',
            title: '2. Calculs de Débits de Perfusion',
            subtitle: 'Formule officielle, conversion d’heures en minutes et exercices corrigés',
            content: `Le débit de perfusion est le volume de soluté administré par unité de temps, exprimé le plus souvent en **gouttes par minute (gttes/min)**.

**Formule standard (avec tubulure adulte standard : 1 mL = 20 gouttes) :**
$$\\text{Débit (gouttes/min)} = \\frac{\\text{Volume total (mL)} \\times 20}{\\text{Durée (en minutes)}}$$

---

### Exercice résolu 1 : Calcul de la vitesse de perfusion
- **Volume à perfuser :** 2 000 mL
- **Temps prescrit :** 20 heures
1. Convertir le temps en minutes : $20 \\text{ h} = 20 \\times 60 = 1\\,200 \\text{ min}$.
2. Convertir le volume en gouttes : $2\\,000 \\text{ mL} \\times 20 \\text{ gttes/mL} = 40\\,000 \\text{ gouttes}$.
3. Calcul du débit :
$$\\text{Débit} = \\frac{40\\,000}{1\\,200} = 33{,}33 \\approx \\mathbf{33\\text{ gouttes/minute}}.$$

---

### Exercice résolu 2 : Calcul de la durée de perfusion
- **Volume à perfuser :** 1 500 mL
- **Débit réglé :** 55 gouttes/minute
1. Nombre total de gouttes : $1\\,500 \\times 20 = 30\\,000 \\text{ gouttes}$.
2. Durée en minutes : $\\frac{30\\,000}{55} = 545{,}45 \\text{ minutes}$.
3. Conversion en heures et minutes :
   - $545{,}45 \\div 60 = 9{,}09 \\text{ heures}$
   - $9 \\text{ heures} \\times 60 = 540 \\text{ minutes}$
   - Reste : $545{,}45 - 540 = 5{,}45 \\text{ min} \\approx 5 \\text{ min}$.
   - Résultat final : **9 heures et 05 minutes (9h05)**.`,
            formulas: [
              {
                name: 'Débit en gouttes/min',
                formula: 'Débit (gttes/min) = (Volume en mL × 20) / Durée en min',
                example: '500 mL en 4h (240 min) = (500 × 20) / 240 = 41,6 ≈ 42 gttes/min'
              },
              {
                name: 'Durée en minutes',
                formula: 'Durée (min) = (Volume en mL × 20) / Débit en gttes/min',
                example: '1000 mL à 30 gttes/min = 20 000 / 30 = 667 min = 11h07 min'
              }
            ]
          },
          {
            id: 'sec-dilutions-doses-formules',
            title: '3. Dilutions, Posologies & Formules Galéniques',
            subtitle: 'Loi de dilution C1V1=C2V2, calculs pédiatriques et SRO',
            content: `**Règle de conservation de la masse lors d'une dilution :**
$$C_1 \\times V_1 = C_2 \\times V_2$$
- $C_1, V_1$ : concentration et volume de la solution mère.
- $C_2, V_2$ : concentration et volume de la solution fille désirée.
- *Volume d'eau à ajouter :* $V_{\\text{eau}} = V_2 - V_1$.

**Tableau de dilution officielle à partir d’une solution mère à 5 g/L :**
- Dilution au 1/2 (2,5 g/L) : prélever 25 mL de mère, ajuster à QSP 50 mL.
- Dilution au 1/4 (1,25 g/L) : prélever 25 mL de mère, ajuster à QSP 100 mL.
- Dilution au 1/5 (1,0 g/L) : prélever 20 mL de mère, ajuster à QSP 100 mL.
- Dilution au 1/10 (0,5 g/L) : prélever 10 mL de mère, ajuster à QSP 100 mL.
- Dilution au 1/20 (0,25 g/L) : prélever 10 mL de mère, ajuster à QSP 200 mL.

---

**Calcul de dose médicamenteuse pédiatrique et adulte :**
- Paramètres déterminants : Âge (ex sirop de codéine > 2 ans : 5 mg/année d'âge/jour), Poids corporel (mg/kg/jour), Surface corporelle ($mg/m^2$, le plus précis en oncologie).
- **Exercice d'application (Cours p. 51) :**
  - Prescription : Aspirine 50 mg/kg/jour en 3 prises chez un sujet de 60 kg pendant 7 jours.
  - Dose journalière : $50 \\text{ mg} \\times 60 = 3\\,000 \\text{ mg/jour} = \\mathbf{3\\text{ g/jour}}$.
  - Dose par prise : $3\\,000 \\div 3 = 1\\,000 \\text{ mg par prise}$.
  - Nombre de comprimés à 500 mg par prise : $1\\,000 \\div 500 = \\mathbf{2\\text{ comprimés par prise}}$.
  - Total pour le traitement de 7 jours : $3\\text{ g} \\times 7 = 21\\text{ g}$ soit **42 comprimés à 500 mg**.

---

**Formules galéniques officielles à connaître par cœur :**
1. **Soluté glucosé isotonique à 5% (m/v) :**
   - Glucose anhydre : 5 g
   - Eau pour préparations injectables (EPPI) : QSP 100 mL
2. **Formule OMS des Sels de Réhydratation Orale (SRO) pour 1 litre d'eau potable :**
   - Chlorure de sodium (NaCl) : **3,5 g**
   - Chlorure de potassium (KCl) : **1,5 g**
   - Citrate trisodique dihydraté : **2,9 g**
   - Glucose anhydre : **20,0 g**
   - Eau potable : QSP **1 000 mL (1 litre)**.`,
            keyTakeaways: [
              'C1 × V1 = C2 × V2 permet de calculer immédiatement le volume de solution mère.',
              'SRO OMS pour 1L : NaCl 3,5g + KCl 1,5g + Citrate trisodique 2,9g + Glucose 20g.',
              'Soluté glucosé isotonique à 5% = 5g pour 100 mL (ou 50g pour 1000 mL).'
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'cours-toxicologie-generale',
    title: 'Généralités Toxicologiques',
    subject: 'Toxicologie',
    badge: '36 pages de cours magistral',
    author: 'Pr TIGORI épse SANGARE B., Pharmacienne, Experte Toxicologue',
    pageCount: 36,
    iconName: 'Biohazard',
    colorScheme: {
      primary: '#0284C7',
      bg: '#F0F9FF',
      light: '#E0F2FE',
      border: '#BAE6FD',
    },
    summary: 'Le cours magistral de référence du Pr TIGORI : définitions, toxicocinétique, cibles biochimiques, voies d’absorption, CAT d’urgence lors d’ingestions, facteurs modulants la toxicité, interactions médicamenteuses, toxiques cumulatifs et cancérogènes.',
    learningObjectives: [
      'Différencier toxicocinétique, toxicodynamie, xénobiotiques, toxiques, poisons et toxines.',
      'Connaître les 8 domaines de la toxicologie moderne (médico-légale, professionnelle, alimentaire, sociale, etc.).',
      'Maîtriser la conduite à tenir d’urgence en cas d’ingestion toxique et les pièges mortels (pourquoi le lait est proscrit).',
      'Identifier les mécanismes moléculaires : formation de carboxyhémoglobine (CO), chélates enzymatiques (cyanures), peroxydation lipidique (CCl4).',
      'Comprendre la bioamplification (drame de Minamata) et les critères d’évaluation de la DJA.'
    ],
    linkedQuizIds: [50, 10, 11, 12],
    chapters: [
      {
        id: 'tox-ch1-bases-domaines',
        number: 1,
        title: 'Bases Fondamentales & Domaines Modernes',
        description: 'Histoire, définitions de Paracelse à Truhaut, et cartographie des 8 disciplines de la toxicologie.',
        sections: [
          {
            id: 'sec-tox-definitions',
            title: '1. Histoire, Éléments Fondateurs & Définitions',
            subtitle: 'Toxicon, Paracelse, Fabre, Truhaut, Xénobiotiques',
            content: `**Étymologie :**
Le mot *toxicologie* provient des termes grecs *toxicon* (qui signifie flèche, en référence aux flèches empoisonnées des guerriers antiques) et *logos* (discours, étude).

**Définitions clés :**
- **Xénobiotique (xenos = étranger, biotos = vie) :** Toute substance étrangère introduite dans un organisme vivant (médicaments, additifs, polluants, pesticides).
  - *Cas particulier de l’Érythropoïétine (EPO) :* Glycoprotéine sécrétée à 90% par le rein sous l'effet de l'hypoxie tissulaire pour stimuler l'érythropoïèse. Lorsqu'elle est administrée à un sportif dans un but de dopage, elle est d'origine exogène et se comporte comme un xénobiotique.
- **Toxique (Définition de René Fabre et René Truhaut) :** Substance qui, après pénétration dans l'organisme à une dose relativement élevée, provoque des troubles d'une ou plusieurs fonctions pouvant aller jusqu'à la mort.
- **Poison :** Synonyme de toxique sur le plan physico-chimique, mais le terme est réservé dans l'usage commun à l'attentat criminel (intention d'homicide).
- **Principe fondamental de Paracelse (XVIe siècle) :** *"Toutes les choses sont poison, et rien n'est sans poison ; seule la dose fait qu'une chose n'est pas un poison."*
- **Toxicocinétique vs Pharmacocinétique :** La toxicocinétique étudie le devenir d'un toxique dans l'organisme (Absorption, Distribution, Métabolisme, Élimination).`,
            keyTakeaways: [
              'Paracelse : C’est la dose qui fait le poison.',
              'Xénobiotique = substance étrangère à l’organisme vivant.',
              'L’EPO exogène utilisée en dopage est un xénobiotique.'
            ]
          },
          {
            id: 'sec-tox-domaines',
            title: '2. Les 8 Domaines de la Toxicologie Moderne',
            subtitle: 'Médico-légale, professionnelle, alimentaire, sociale, écotoxicologie...',
            content: `1. **Toxicologie médico-légale / expertise judiciaire :**
   - Recherche et dosage des toxiques chez la victime (autopsie médico-légale sur sang, urines, contenu gastrique, foie, rein).
   - Conservation des prélèvements : au moins 7 ans (jusqu'à 20 ans aux USA) pour permettre une contre-expertise.
2. **Hygiène alimentaire & Toxicologie agro-alimentaire :**
   - Contrôle des additifs, résidus de pesticides et mycotoxines (aflatoxines, ochratoxine A).
   - Détermination de la **DJA (Dose Journalière Acceptable)** : dose maximale qu'un être humain peut consommer quotidiennement tout au long de sa vie sans risque appréciable pour la santé.
3. **Toxicologie professionnelle (du travail) :**
   - Étude des toxiques industriels sur les postes de travail.
   - Le médecin du travail doit consacrer au moins **un tiers de son temps (notion de tiers-temps)** en milieu réel dans les ateliers.
   - Bilan biologique d'embauche systématique (NFS).
   - *Exemple du trichloréthylène :* Solvant dégraissant très volatil (textile, colles). Symptômes : céphalées, baisse de libido, arythmies cardiaques, intolérance à l'alcool ("flush" du trichloréthylène).
4. **Hygiène sociale (Toxicologie sociale) :**
   - Étude des toxicomanies et pharmacodépendances.
   - Définition de Fouquet : Le toxicomane est un patient qui a *"perdu la liberté de s'abstenir du toxique"*.
   - Définition d'Olievenstein : La toxicomanie est la rencontre d'une personnalité, d'un produit et d'un moment socioculturel.
   - Sécurité routière : limite légale d'alcoolémie fixée à 0,5 g/L de sang (l'éthanol est impliqué dans une forte proportion des accidents mortels).
5. **Écotoxicologie (Toxicologie de l’environnement) :**
   - Pollution des sols, des eaux (lagune Ébrié) et de l'air.
   - Drame historique du **Probo Koala (août 2006)** à Abidjan (déversement de déchets toxiques à la décharge d'Akouédo).
6. **Toxicologie réglementaire :**
   - Établissement des normes et seuils d'exposition par les organismes publics (ex : **CODINORM** en Côte d'Ivoire).
7. **Biotoxicologie & Essais d'AMM :**
   - Évaluation préclinique obligatoire de tout candidat-médicament.
8. **Toxicologie clinique :**
   - Prise en charge des urgences et intoxications au lit du malade.`,
            keyTakeaways: [
              'DJA = dose maximale ingérable chaque jour toute la vie sans risque.',
              'Médecin du travail = 1/3 de son temps sur le terrain en atelier.',
              'Délai de conservation des scellés judiciaires = 7 ans minimum.'
            ]
          }
        ]
      },
      {
        id: 'tox-ch2-mecanismes-urgence',
        number: 2,
        title: 'Mécanismes, Voies d’Absorption & Conduite à Tenir',
        description: 'Cibles biochimiques, détoxification vs détoxication et prise en charge d’urgence des intoxications.',
        sections: [
          {
            id: 'sec-tox-notions-cibles',
            title: '1. Cibles Moléculaires & Organes Cibles',
            subtitle: 'CO, cyanures, CCl4, méthanol et récepteurs',
            content: `**Classification temporelle des expositions :**
- *Intoxication aiguë :* Exposition unique ou multiple n'excédant pas **24 heures**.
- *Intoxication suraiguë :* Troubles foudroyants en quelques heures à 2-3 jours.
- *Intoxication subaiguë :* Exposition répétée sur **14 à 90 jours** (ou quelques semaines, ex: 3 semaines Akouédo).
- *Intoxication chronique :* Exposition répétée sur **plus de 3 mois à plusieurs années**.

**Cibles biochimiques des toxiques :**
1. **Protéines et transporteurs :**
   - *Monoxyde de carbone (CO) :* Affinité pour l'hémoglobine 200 à 250 fois supérieure à celle de l'oxygène -> formation de carboxyhémoglobine (HbCO), provoquant une anoxie tissulaire mortelle.
   - *Méthémoglobinisants :* Nitrites, dérivés aromatiques oxydant le fer ferreux $Fe^{2+}$ en fer ferrique $Fe^{3+}$ inapte au transport d'O2.
2. **Coenzymes :**
   - *Cyanures :* Forment des chélates stables avec les métaux (fer, cuivre, zinc) des cytochromes respiratoires mitochondriaux -> asphixie cellulaire foudroyante.
3. **Lipides :**
   - *Tétrachlorure de carbone ($CCl_4$) :* Bioactivé en radical libre trichlorométhyle ($CCl_3^\\bullet$) déclenchant la peroxydation lipidique des membranes hépatocytaires et la nécrose du foie.
4. **Acides nucléiques :**
   - *Agents alkylants :* Liaisons covalentes sur l'ADN -> mutations et cancers.
   - *Antimétabolites (méthotrexate) :* Blocage de la réplication cellulaire.

**Organes cibles principaux : Foie et Reins.**
- *Exemple du méthanol :* Métabolisé par l'alcool déshydrogénase (ADH) en formaldéhyde puis en acide formique. L'acide formique s'accumule dans la rétine humaine et détruit le nerf optique (cécité bilatérale irréversible).`,
            keyTakeaways: [
              'CO : affinité Hb 200-250× supérieure à O2 -> Carboxyhémoglobine.',
              'Cyanures : blocage respiratoire mitochondrial par chélation métallique.',
              'Méthanol -> acide formique = cécité irréversible.'
            ]
          },
          {
            id: 'sec-tox-detox-cat',
            title: '2. Détoxification vs Détoxication & Urgences Toxiques',
            subtitle: 'CAT lors d’ingestions et avertissement majeur sur le lait',
            content: `**Distinction fondamentale :**
- **DÉTOXIFICATION :** Opération ayant lieu **AVANT la pénétration** du toxique dans l'organisme. Traitement in vitro des denrées alimentaires ou de l'environnement pour éliminer le poison (ex : traitement à l'ozone $O_3$, rayons gamma, adsorption sur argile ou charbon actif).
- **DÉTOXICATION :** Processus biologique ayant lieu **APRÈS la pénétration** du toxique dans l'organisme. Ensemble des réactions métaboliques enzymatiques (foie) visant à transformer le toxique en métabolites hydrosolubles éliminables.

---

**Conduite à Tenir (CAT) en cas d’ingestion toxique malheureuse :**
- **Si moins d'une heure (< 1h) :** Faire vomir la victime (titiller la luette ou administrer du sirop d'ipéca), *sauf contre-indications absolues : produits moussants, caustiques/acides/bases fortes, hydrocarbures ou patient comateux (risque de fausse route pulmonaire)*.
- **Entre 1 heure et 2 heures :** Administrer un pansement gastrique adsorbant universel : **Charbon activé** (ou Maalox / Phosphalugel). Le charbon piège le toxique dans la lumière digestive et empêche son absorption.
- **Après 3 heures :** Administrer un laxatif ou purgatif pour accélérer l'évacuation intestinale.

---

⚠️ **MISE EN GARDE MÉDICALE MAJEURE (Pr TIGORI) :**
> **LE LAIT N'EST EN AUCUN CAS UN ANTIDOTE !**
> La croyance populaire selon laquelle le lait "neutraliserait" ou "désintoxiquerait" les ouvriers manipulant des solvants ou des pesticides est scientifiquement **FAUSSE ET DANGEREUSE**.
> Le lait est riche en lipides : il agit comme un véhicule lipophile qui solubilise les toxiques liposolubles (pesticides organophosphorés, benzène, solvants) et **AUGMENTE leur absorption digestive et leur toxicité systémique** !
> Lors du drame du Probo Koala en 2006, la consigne toxicologique stricte était **l'éviction totale des aliments gras (lait, sauce graine, sauce arachide, sauce pistache)**.`,
            keyTakeaways: [
              'Détoxification = avant pénétration ; Détoxication = après pénétration.',
              'CAT ingestion : <1h = vomissements ; 1-2h = charbon activé ; >3h = laxatif.',
              'LE LAIT N’EST PAS UN ANTIDOTE : il augmente l’absorption des toxiques gras !'
            ]
          },
          {
            id: 'sec-tox-facteurs-interactions',
            title: '3. Facteurs Modulants, Tolérance & Interactions',
            subtitle: 'Voies, génétique raciale, Mithridate, synergies, inducteurs et inhibiteurs',
            content: `**Facteurs liés à l'organisme hôte :**
- **Espèce :** L'atropine est mortelle pour l'homme mais supportée à fortes doses par les rongeurs (lapins possédant l'atropine-estérase).
- **Différences raciales et pharmacogénétique :** Les sujets asiatiques et amérindiens sont des acétyleurs rapides de l'isoniazide (INH), tandis que les sujets caucasiens et noirs présentent une proportion élevée d'acétyleurs lents (risque accru de neuropathies et d'hépatotoxicité).
- **Âge :** Les nouveau-nés (immaturité enzymatique hépatique et rénale) et les personnes âgées sont les plus vulnérables.
- **État de jeûne :** La toxicité par voie orale est accrue à jeun en raison de l'absence de bol alimentaire ralentisseur et du risque d'hypoglycémie.
- **Rythme circadien & Botanique :** Les stomates des plantes médicinales s'ouvrent entre **3 heures et 4 heures du matin** pour libérer leurs essences ; après le lever du soleil, elles se referment et perdent leur activité volatile.

**Phénomènes d'adaptation :**
- **Idiosyncrasie (intolérance naturelle) :** Réactivité anormale génétiquement déterminée dès la naissance (ex: enfant intolérant à la pénicilline sans contact préalable).
- **Tolérance (Mithridatisation) :** Diminution progressive de l'effet d'une substance après administration répétée (ex : le roi Mithridate qui s'immunisait en ingérant des doses croissantes d'arsenic).
- **Dépendance :** Psychique (nicotine du tabac) ou physique avec syndrome de sevrage (alcoolisme, héroïne avec delirium tremens).

**Interactions toxiques et médicamenteuses :**
- **Synergie additive :** Effet global = somme des effets ($1 + 1 = 2$).
- **Synergie renforçatrice :** Effet global > somme des effets ($1 + 1 > 2$).
- **Potentialisation :** Une substance inactive seule augmente considérablement l'effet toxique d'une autre ($0 + 1 = 3$).
- **Antagonisme compétitif :** Deux substances luttent pour le même récepteur (ex : Flumazénil antidote des benzodiazépines).
- **Induction enzymatique :** Augmentation de l'activité des cytochromes P450 (tabac, alcool chronique, rifampicine, phénobarbital) -> accélère la dégradation d'autres médicaments.
- **Inhibition enzymatique :** Ralentissement du métabolisme -> surdosage (ex : alcool en prise aiguë, jus de pamplemousse). L'éthanol est l'antidote du méthanol car il sature l'ADH avec une affinité 10 fois supérieure.

**Toxiques cumulatifs & Bioamplification :**
- Substances liposolubles et persistantes s'accumulant dans les tissus adipeux : insecticides organochlorés (**DDT**), métaux lourds (**Plomb, Mercure, Cadmium**), arsenic et fluor.
- **Bioamplification (Chaîne trophique) :** Concentration croissante du polluant de maillon en maillon (algue -> petit poisson -> grand poisson -> homme). Exemple célèbre de la **baie de Minamata (Japon 1950)** : rejets de mercure par une usine plastique, transformé en méthylmercure par les sédiments, causant des troubles neurologiques congénitaux sévères chez les enfants de pêcheurs.`,
            keyTakeaways: [
              'Tolérance = adaptation à des doses croissantes (Mithridate).',
              'Éthanol = antidote du méthanol (compétition pour l’ADH).',
              'Minamata 1950 = exemple historique de bioamplification du mercure.'
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'cours-logistique-sante',
    title: 'Gestion des Produits de Santé & Logistique',
    subject: 'Gestion Logistique',
    badge: '44 pages & Exercices officiels',
    author: 'Programme National de Gestion Pharmaceutique PGP1',
    pageCount: 44,
    iconName: 'Truck',
    colorScheme: {
      primary: '#059669',
      bg: '#ECFDF5',
      light: '#D1FAE5',
      border: '#A7F3D0',
    },
    summary: 'Le cours complet de Logistique Pharmaceutique PGP1 : définitions légales, LNME, DCI, MQIF, PPI, dispositifs médicaux, kits, chaîne d’approvisionnement en Côte d’Ivoire (NPSP-CI & grossistes privés), 4 étapes de quantification et systèmes PUSH/PULL.',
    learningObjectives: [
      'Connaître la définition légale du médicament selon la loi n° 2015-533 de Côte d’Ivoire.',
      'Comprendre la sélection LNME et le rôle clé de la DCI.',
      'Savoir identifier les MQIF (médicaments falsifiés) et la procédure réglementaire de gestion des PPI.',
      'Cartographier la chaîne logistique ivoirienne (secteur public NPSP-CI vs grossistes répartiteurs privés).',
      'Maîtriser les 4 méthodes et les 4 étapes de la quantification (CMM, morbidité, PUSH, PULL).'
    ],
    linkedQuizIds: [30, 31, 32, 40, 20, 21, 22],
    chapters: [
      {
        id: 'log-ch1-generalites',
        number: 1,
        title: 'Chapitre I : Généralités sur les Produits de Santé',
        description: 'Cadre légal, classification, DCI, LNME, contrefaçons (MQIF) et gestion des déchets (PPI).',
        sections: [
          {
            id: 'sec-log-definition-medicament',
            title: '1. Définition Légale & Classification des Produits de Santé',
            subtitle: 'Loi n° 2015-533, DCI, princeps, générique, LNME',
            content: `**Définition du Médicament selon la loi n° 2015-533 du 20 juillet 2015 (Côte d’Ivoire) :**
Toute drogue, substance, composition ou préparation présentée comme possédant des propriétés curatives ou préventives à l'égard des maladies humaines ou animales, ainsi que tout produit pouvant être administré en vue d'établir un diagnostic médical ou de restaurer, corriger ou modifier leurs fonctions organiques.

**Sont assimilés aux médicaments :**
- Produits diététiques renfermant des substances chimiques ou biologiques non alimentaires conférant des propriétés thérapeutiques spéciales.
- **Produits stables préparés à partir du sang et de ses composants (MDS)** : albumine, immunoglobulines, facteurs de coagulation. *(Attention : les Produits Sanguins Labiles PSL tels que concentrés de globules rouges ou plaquettes sont gérés directement par le CNTS)*.
- Produits de sevrage tabagique (substituts nicotiniques réduisant l'accoutumance au tabac).

**NE sont PAS des médicaments :**
- Objets de pansement (compresses, bandages) -> ce sont des **Dispositifs Médicaux (DM)** consommables.
- Produits pour prothèses dentaires -> DM.
- Produits pour désinfection des locaux et détergents -> produits d'entretien.

---

**Notions clés de logistique :**
- **DCI (Dénomination Commune Internationale) :** Nom scientifique universel attribué par l'OMS au principe actif. Standardise les commandes et sécurise les approvisionnements mondiaux.
- **LNME (Liste Nationale des Médicaments Essentiels) :** Liste des médicaments qui satisfont aux besoins prioritaires de santé de la majorité de la population.
  - En Côte d'Ivoire, la LNME est **révisée tous les deux (2) ans**.
  - *Critères de sélection :* Prévalence des maladies, efficacité reconnue, sécurité prouvée, facilité d'emploi (posologie simple), coût le plus faible possible (rapport coût/efficacité optimal).
- **Spécialité pharmaceutique (princeps) vs Médicament générique :** Le générique a la même composition qualitative et quantitative en principes actifs, la même forme galénique et une bioéquivalence démontrée avec le médicament de référence.
- **Notion de lot et de péremption :** Unité homogène de production. La date de péremption indique la limite au-delà de laquelle l'efficacité et la stabilité ne sont plus garanties.`,
            keyTakeaways: [
              'Loi 2015-533 : médicament = curatif, préventif, diagnostique ou restaurateur.',
              'LNME révisée tous les 2 ans en Côte d’Ivoire.',
              'Pansements et prothèses dentaires = Dispositifs Médicaux, pas des médicaments.'
            ]
          },
          {
            id: 'sec-log-mqif-ppi-dm',
            title: '2. MQIF, PPI, Dispositifs Médicaux & Kits',
            subtitle: 'Contrefaçons, quarantaine des périmés et les 3 classes de DM',
            content: `**1. Médicaments de Qualité Inférieure ou Falsifiés (MQIF) :**
Selon l'OMS, un produit médical est falsifié lorsqu'il y a une fausse représentation de son identité, de sa composition ou de sa source.
- *Causes :* Non-respect des BPF (Bonnes Pratiques de Fabrication), transport inadapté, mauvaise conservation, imitation frauduleuse sans principe actif ou sous-dosé.
- *Conséquences :* Échec thérapeutique, décès, développement de résistances aux antimicrobiens, perte de confiance dans le système de santé.
- *Régulateur national :* **AIRP** (Agence Ivoirienne de Régulation Pharmaceutique).

**2. Produits Pharmaceutiques Inutilisables (PPI) :**
- Produits périmés.
- Produits avariés (cassés, précipités, défauts de fabrication).
- Médicaments dont la chaîne du froid a été interrompue (insuline, vaccins, ocytocine, sérums).
- Sirops, collyres ou pommades dont l'emballage a été ouvert.
- Produits retirés du marché (rappels de lots).
*Procédure légale :* Identification immédiate -> **Mise en quarantaine** séparée -> Destruction sécurisée par une commission agréée avec procès-verbal officiel. La pharmacie **ne peut pas** détruire unilatéralement les PPI.

**3. Dispositifs Médicaux (DM) :**
Instruments, équipements, implants ou consommables utilisés à des fins diagnostiques ou préventives sans action pharmacologique principale.
- *3 Grandes classes usuelles :*
  1. **Consommables :** Seringues, gants d'examen, compresses, cathéters, perfuseurs (usage unique).
  2. **Durables :** Autoclaves, lits d'hospitalisation, microscopes, tensiomètres.
  3. **Réactifs / DMDIV :** Tests rapides, automates de laboratoire, bandelettes urinaires.

**4. Les Kits Médicaux :**
Ensembles standardisés regroupant médicaments, consommables et DM pour une prise en charge ciblée (kits d'accouchement, kits de césarienne, kits d'urgence humanitaire, kits IST).`,
            keyTakeaways: [
              'MQIF = contrefaçons et sous-dosages combattus par l’AIRP.',
              'PPI = mise en quarantaine obligatoire, interdiction de destruction unilatérale.',
              '3 classes de DM : Consommables, Durables, Réactifs de laboratoire (DMDIV).'
            ]
          }
        ]
      },
      {
        id: 'log-ch2-chaine-approvisionnement',
        number: 2,
        title: 'Chapitre II : Chaîne d’Approvisionnement des Produits de Santé',
        description: 'Flux, acteurs en Côte d’Ivoire, NPSP-CI, quantification des besoins et systèmes PUSH/PULL.',
        sections: [
          {
            id: 'sec-log-flux-acteurs',
            title: '1. Les 3 Flux & Circuits de Distribution en Côte d’Ivoire',
            subtitle: 'Flux physique, informationnel, financier ; NPSP-CI vs grossistes privés',
            content: `**La triade des flux logistiques :**
1. **Flux physique :** Déplacement matériel des produits du fabricant jusqu'au patient final à travers les entrepôts et le transport sécurisé.
2. **Flux d’information :** Données qui pilotent le flux physique (niveaux de stocks, consommations moyennes mensuelles CMM, commandes, péremptions, températures de chaîne du froid).
3. **Flux financier :** Mobilisation et circulation des ressources financières (achats, paiements, subventions de bailleurs de fonds comme le Fonds Mondial, GAVI, USAID).

---

**Organisation des deux circuits en Côte d’Ivoire :**
- **Circuit Public National :**
  - **Centrale d'achat nationale : NPSP-CI** (Nouvelle Pharmacie de la Santé Publique de Côte d'Ivoire).
  - *Échelons de stockage (4 niveaux) :*
    1. Niveau central (NPSP Agence principale Abidjan).
    2. Niveau régional (Agence régionale de Bouaké & antennes).
    3. Niveau intermédiaire (Districts sanitaires, hôpitaux CHU / CHR / HG).
    4. Niveau périphérique (ESPC : Centres de Santé Ruraux CSR, Centres de Santé Urbains CSU).
- **Circuit Privé :**
  - Assuré par des **Grossistes-répartiteurs privés** (ex : UBIPHARM, COPHARMED, DPCI / TEDIS PHARMA).
  - Ils s'approvisionnent auprès des laboratoires internationaux pour distribuer aux officines de pharmacie privées.`,
            keyTakeaways: [
              '3 flux inséparables : Physique, Informationnel, Financier.',
              'Secteur public = NPSP-CI (Abidjan et Bouaké).',
              'Secteur privé = Grossistes-répartiteurs (UBIPHARM, COPHARMED, DPCI) vers officines.'
            ]
          },
          {
            id: 'sec-log-quantification-push-pull',
            title: '2. Quantification des Besoins & Systèmes PUSH / PULL',
            subtitle: 'CMM, prévisions, méthodes et modes de distribution',
            content: `**Définition de la Quantification :**
Processus d'estimation des quantités et des coûts de produits nécessaires pour une période donnée, et planification du calendrier des livraisons.

**Les 4 étapes de la quantification (Figure 1 du cours) :**
1. *Préparation :* Collecte des données, hypothèses et méthodologie.
2. *Prévisions (Forecasting) :* Estimation des besoins futurs.
3. *Planification des approvisionnements (Supply Planning) :* Calendrier de commandes selon les financements disponibles (logiciels Pipeline, Quantimed, Forlab).
4. *Révision et actualisation :* Réajustement périodique.

**Les 4 méthodes de quantification :**
1. **Méthode de consommation historique (CMM) :** Basée sur la Consommation Moyenne Mensuelle passée corrigée des ruptures de stock.
2. **Méthode de morbidité (épidémiologique) :** Basée sur l'incidence/prévalence des pathologies et les protocoles de traitement standard.
3. **Méthode des statistiques de service :** Basée sur le nombre de consultations, lits occupés ou actes médicaux réalisés.
4. **Méthode démographique :** Basée sur la population cible et les taux de couverture.

---

**Modes d'acquisition et de distribution :**
- **Adjudication (Appel d'offres) :** Mode standard de mise en concurrence pour les marchés publics entre fournisseurs et centrale d'achat.
- **Système d'allocation ou "PUSH" :** Le niveau supérieur calcule et détermine les quantités de produits attribuées et expédiées au niveau inférieur (système poussé).
- **Système de réquisition ou "PULL" :** Le niveau inférieur (utilisateur) calcule ses besoins à partir de ses consommations réelles et passe commande au niveau supérieur (système tiré).

**Produits à exigences particulières :**
- **Vaccins :** Chaîne du froid continue stricte entre **+2°C et +8°C**, distribution pilotée par l'INHP (Institut National d'Hygiène Publique).
- **Produits Sanguins :** Traçabilité et hémovigilance absolue gérées par le CNTS et les CRTS.`,
            keyTakeaways: [
              'CMM = Consommation Moyenne Mensuelle.',
              'PUSH (Allocation) : le niveau supérieur décide des quantités envoyées.',
              'PULL (Réquisition) : le niveau inférieur commande selon ses besoins.',
              'Chaîne du froid vaccins = +2°C à +8°C en continu.'
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'cours-galenique-matieres-premieres',
    title: 'Pharmacie Galénique : Matières Premières & Excipients',
    subject: 'Galénique',
    badge: '41 pages de cours',
    author: 'UE Galénique PGP1',
    pageCount: 41,
    iconName: 'Pill',
    colorScheme: {
      primary: '#D97706',
      bg: '#FFFBEB',
      light: '#FEF3C7',
      border: '#FDE68A',
    },
    summary: 'Rôle et critères d’inertie des excipients, liste des EEN (excipients à effet notoire), classification par origine (végétale, animale, minérale, synthétique), étude des glycérides, des PEG, des hydrocarbures et classification des principes actifs.',
    learningObjectives: [
      'Définir le rôle d’un excipient et ses 3 exigences d’inertie (vis-à-vis du PA, du patient, du conditionnement).',
      'Identifier les excipients à effet notoire (EEN) et leurs risques associés.',
      'Classer les excipients par origine (végétale, animale, minérale, synthétique) et connaître leurs propriétés galéniques.',
      'Distinguer les glycérides liquides, pâteux (beurre de karité) et solides (beurre de cacao).',
      'Comprendre la classification des principes actifs et l’évolution vers les biotechnologies.'
    ],
    linkedQuizIds: [60, 61],
    chapters: [
      {
        id: 'gal-ch1-excipients',
        number: 1,
        title: 'Chapitre I : Généralités sur les Excipients',
        description: 'Définitions, qualités d’inertie, excipients à effet notoire et monographies détaillées.',
        sections: [
          {
            id: 'sec-excipient-definition-roles',
            title: '1. Rôles & Critères Fondamentaux d’Inertie',
            subtitle: 'Définition, fonctions et les 3 niveaux d’inertie exigés',
            content: `**Définition :**
Un excipient désigne toute substance autre que le principe actif entrant dans la composition d'un médicament, d'un cosmétique ou d'un aliment. C'est une substance inactive d'un point de vue thérapeutique, indispensable pour accompagner et véhiculer le principe actif.
*L'excipient est le vecteur ou le véhicule du PA : il permet au principe actif de parvenir là où il doit agir.*

**Rôles majeurs de l’excipient :**
1. *Permettre la réalisation de la forme galénique* (comprimé, sirop, pommade, suppositoire).
2. *Faciliter l'administration* et améliorer l'acceptabilité (goût, aspect, consistance).
3. *Améliorer l'efficacité du PA* (action locale ou modulation de l'absorption systémique).
4. *Assurer la stabilité et la conservation* (tampon de pH, conservateurs antimicrobiens comme parabènes et acide sorbique, antioxydants).

**Les 3 Niveaux d’Inertie de l’Excipient :**
- **Inertie vis-à-vis du principe actif :** Absence totale de réaction chimique ou dégradation du PA pour éviter la formation de produits toxiques.
- **Inertie vis-à-vis du malade :** Totale absence d'activité pharmacodynamique propre (innocuité physiologique).
- **Inertie vis-à-vis du conditionnement primaire :** Pas d'attaque du contenant (verre, plastique, aluminium) par l'excipient et pas de relargage de substances du contenant vers le médicament.

---

**Excipients à Effet Notoire (EEN) :**
Excipients dont la présence peut nécessiter des précautions d'emploi chez des sujets sensibles (mention obligatoire sur la notice et l'emballage, non interdits !) :
- *Risque allergique :* Huile d'arachide, colorants azoïques, baume du Pérou, fructose, glucose, saccharose, parabènes.
- *Trouble digestif :* Glycérol.
- *Irritation locale :* Chlorure de benzalkonium, acide benzoïque, benzoates, lanoline.
- *Risque toxique :* Éthanol (femmes enceintes, enfants).`,
            keyTakeaways: [
              'L’excipient doit être inerte chimiquement, pharmacologiquement et vis-à-vis du récipient.',
              'Les EEN ne sont pas interdits mais strictement réglementés.',
              'Le véhicule achemine le PA à son site d’action.'
            ]
          },
          {
            id: 'sec-excipient-classification',
            title: '2. Origines & Monographies d’Excipients',
            subtitle: 'Végétaux, animaux, minéraux, synthétiques, glycérides, PEG et hydrocarbures',
            content: `**1. Excipients d'origine végétale :**
- *Amidon (blé, maïs, riz, pomme de terre) :* Solide hydrophile blanc, diluant et désintégrant pour comprimés.
- *Cellulose et dérivés :*
  - Méthylcellulose : polymère gélifiant hydrophile, épaississant pour potions gommeuses.
  - **Acétophtalate de cellulose (CAP) :** Insoluble en milieu acide stomacal, très soluble en milieu alcalin intestinal -> **enrobage gastro-résistant**.
  - Carboxyméthylcellulose (CMC) : liant hygroscopique.
- *Gommes (arabique, adragante, karaya, guar) :* Exsudats d'arbres, liants hydrophiles pour pilules et émulsions.
- *Sucres :* Glucose (calorique, cariogène), Saccharose (sirop simple), Miel, Fructose (sucre de fruit pour diabétiques).

**2. Excipients d'origine animale :**
- *Gélatine :* Obtenue par ébullition prolongée des tissus conjonctifs (peaux) et os animaux (collagène). Solide hydrophile utilisé pour la fabrication des gélules et capsules de médicaments. *Il n'existe pas de gélatine végétale !*
- *Lactose :* Sucre extrait du lait animal, diluant pulvérulent neutre le plus utilisé pour gélules et comprimés.
- *Lanoline :* Cire purifiée recueillie à partir de la graisse de laine de mouton (suint), très émolliente et amphiphile pour pommades.
- *Cires animales :* Cire d'abeille (sécrétée par Apis mellifera), Cire de cachalot (spermaceti, cavité crânienne).

**3. Excipients d'origine minérale :**
- *Chlorure de sodium (NaCl) :* Isotonisant standard des préparations injectables et collyres.
- *Talc (silicate de magnésium hydraté) :* Lubrifiant d'écoulement pour poudres et comprimés.
- *Oxyde de titane ($TiO_2$) :* Agent opacifiant blanc pour gélules et crèmes solaires.
- *Silices colloïdales :* Écoulement et anti-mottant.

**4. Excipients d'origine synthétique :**
- *Carbomères (Carbopols) :* Polymères d'acide acrylique réticulé formant des gels hydrophiles neutres.
- *Macrogols (Polyéthylène glycol - PEG) :*
  - Liquides si masse molaire < 600 g/mol (PEG 300, PEG 400).
  - Pâteux ou solides si masse molaire > 800 g/mol (PEG 1500, PEG 4000).
  - *Usage thérapeutique :* **PEG 4000** est un laxatif osmotique majeur retenant l'eau dans le côlon par liaisons hydrogène.
- *Hydrocarbures saturés :*
  - **Vaseline blanche ou jaune :** Hydrocarbure purifié du pétrole, excipient lipophile gras occlusif non pénétrant pour pommades.
  - *Remarque :* La vaseline officinale est en elle-même un médicament protecteur cutané.
  - **Paraffine solide et liquide :** Alcanes saturés en $C_n H_{2n+2}$ pour cires et lubrifiants.`,
            keyTakeaways: [
              'Acétophtalate de cellulose = enrobage gastro-résistant.',
              'Gélatine = strictement animale (collagène osseux et cutané).',
              'PEG 4000 = laxatif osmotique par rétention d’eau.',
              'Vaseline = hydrocarbure lipophile occlusif non pénétrant.'
            ]
          }
        ]
      },
      {
        id: 'gal-ch2-principes-actifs',
        number: 2,
        title: 'Chapitre II : Généralités sur les Principes Actifs',
        description: 'Nature des PA, phytothérapie, opothérapie, biotechnologies et synthèse.',
        sections: [
          {
            id: 'sec-pa-nature-origines',
            title: '1. Nature & Origines des Principes Actifs',
            subtitle: 'Produits définis vs non définis, plantes, opothérapie, biotechnologies',
            content: `Le principe actif (PA) est la substance chimique ou biologique responsable de l'activité thérapeutique du médicament.

**1. Nature du Principe Actif :**
- **Produit défini :** Molécule chimique pure obtenue par synthèse, dont la structure, le poids moléculaire et la pureté sont rigoureusement décrits à la Pharmacopée (ex : Acide acétylsalicylique, PM 180,2 g/mol, point de fusion 143°C).
- **Produit non défini :** Mélange complexe obtenu par extraction naturelle à partir de plantes ou d'animaux (ex : Opium = latex extrait par incision des capsules de *Papaver somniferum album* ; Huile de foie de morue = riche en vitamines A et D).

**2. Les Origines des Principes Actifs :**
- **Origine végétale (Phytothérapie) :**
  - Tisanes (macération, digestion, décoction, infusion, percolation).
  - Teintures alcooliques (rapport plante séchée/alcool = 1/5, degré 60° à 70°).
  - Extraits (fluides, mous, secs, nébulisâts).
  - Huiles essentielles (HE d'eucalyptus antiseptique, HE de menthe poivrée) obtenues par distillation à la vapeur d'eau en alambic.
  - PA purs isolés de plantes : Digitaline (feuilles de digitale, cardiotonique isolé par Nativelle en 1868), Quinine (écorce de quinquina, fébrifuge isolé par Pelletier et Caventou en 1820).
- **Origine animale (Opothérapie) :**
  - Traitement par les tissus ou organes animaux (poudre de pancréas, extrait de bile ou thyroïde).
  - *Problèmes majeurs :* Activité inconstante, mauvaise odeur, risque de transmission de prions pathogènes (**Encéphalopathie Bovine Spongiforme - ESB**) -> ont conduit à l'abandon des poudres opothérapiques au profit des constituants purifiés et de la biotechnologie.
- **Origine microbiologique et biotechnologique (Essor moderne) :**
  - Micro-organismes vivants : levures (*Saccharomyces boulardii* probiotique), ferments lactiques.
  - Produits de fermentation : antibiotiques (pénicilline issue de *Penicillium*).
  - Protéines recombinantes et génie génétique : Insuline humaine recombinante, Hormone de croissance, Érythropoïétine (EPO), Facteurs antihémophiliques, Interférons, Anticorps monoclonaux antitumoraux.
- **Origine minérale :**
  - Sels purgatifs (sulfate de magnésium, sulfate de sodium).
  - Anti-acides (bicarbonate de sodium).
  - Bipolaires (carbonate de lithium).
- **Origine synthétique :**
  - Plus de 80% des médicaments modernes proviennent de la synthèse et de la modélisation moléculaire assistée par ordinateur.`,
            keyTakeaways: [
              'Digitaline (1868) et Quinine (1820) = premiers PA purs isolés de plantes.',
              'L’opothérapie a été délaissée en raison des risques de contamination par prions (ESB).',
              'La biotechnologie produit aujourd’hui l’insuline, l’EPO et les anticorps monoclonaux.'
            ]
          }
        ]
      }
    ]
  }
];

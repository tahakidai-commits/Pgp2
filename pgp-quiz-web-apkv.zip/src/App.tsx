import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { HomeScreen } from './components/HomeScreen';
import { CoursesScreen } from './components/CoursesScreen';
import { CourseDetailScreen } from './components/CourseDetailScreen';
import { QuizListScreen } from './components/QuizListScreen';
import { QuizPlayScreen } from './components/QuizPlayScreen';
import { QuizResultScreen } from './components/QuizResultScreen';
import { DoctorDetailScreen } from './components/DoctorDetailScreen';
import { FlashcardsScreen } from './components/FlashcardsScreen';
import { CalculatorsModal } from './components/CalculatorsModal';
import { HistoryModal } from './components/HistoryModal';
import { QuizEditorModal } from './components/QuizEditorModal';
import { COURSES_DATA } from './data/coursesData';
import { INITIAL_QUIZZES, INITIAL_QUESTIONS } from './data/quizzesData';
import { Course, Quiz, Question, QuizAttempt } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<number>(0); // 0: Accueil, 1: Cours, 2: Quiz, 3: Profil
  const [courses] = useState<Course[]>(COURSES_DATA);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

  // Quizzes & Questions state
  const [quizzes, setQuizzes] = useState<Quiz[]>(() => {
    try {
      const saved = localStorage.getItem('pgp_quizzes');
      if (saved) {
        const parsed: Quiz[] = JSON.parse(saved);
        const customQuizzes = parsed.filter((q) => !q.isBuiltIn);
        return [...INITIAL_QUIZZES, ...customQuizzes];
      }
    } catch (e) {
      console.error(e);
    }
    return INITIAL_QUIZZES;
  });

  const [questionsMap, setQuestionsMap] = useState<Record<number, Question[]>>(() => {
    try {
      const saved = localStorage.getItem('pgp_questions');
      if (saved) {
        const parsed = JSON.parse(saved);
        return { ...parsed, ...INITIAL_QUESTIONS };
      }
    } catch (e) {
      console.error(e);
    }
    return INITIAL_QUESTIONS;
  });

  // User attempts state
  const [attempts, setAttempts] = useState<QuizAttempt[]>(() => {
    try {
      const saved = localStorage.getItem('pgp_attempts');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [];
  });

  // Active quiz play state
  const [activeQuizSession, setActiveQuizSession] = useState<{
    quiz: Quiz;
    questions: Question[];
    isPractice: boolean;
  } | null>(null);

  // Result view state
  const [activeResult, setActiveResult] = useState<{
    quiz: Quiz;
    questions: Question[];
    userAnswers: Record<number, string[]>;
    timeElapsed: number;
  } | null>(null);

  // Modals state
  const [showCalculators, setShowCalculators] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [showQuizEditor, setShowQuizEditor] = useState(false);

  // Persist state to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('pgp_quizzes', JSON.stringify(quizzes));
    } catch (e) {
      console.error(e);
    }
  }, [quizzes]);

  useEffect(() => {
    try {
      localStorage.setItem('pgp_questions', JSON.stringify(questionsMap));
    } catch (e) {
      console.error(e);
    }
  }, [questionsMap]);

  useEffect(() => {
    try {
      localStorage.setItem('pgp_attempts', JSON.stringify(attempts));
    } catch (e) {
      console.error(e);
    }
  }, [attempts]);

  // Handler: start quiz
  const handleStartQuiz = (quiz: Quiz, isPractice: boolean) => {
    // If questions exist in questionsMap, use them; otherwise fallback to flagship
    let qList = questionsMap[quiz.id];
    if (!qList || qList.length === 0) {
      // Fallback
      qList = questionsMap[4] || [];
    }
    setSelectedCourse(null);
    setActiveResult(null);
    setActiveQuizSession({
      quiz,
      questions: qList,
      isPractice,
    });
  };

  const handleStartQuizById = (quizId: number) => {
    const targetQuiz = quizzes.find((q) => q.id === quizId) || quizzes[0];
    if (targetQuiz) {
      handleStartQuiz(targetQuiz, true); // default to practice mode when launched from a course
    }
  };

  // Handler: finish quiz and record attempt
  const handleFinishQuiz = (userAnswers: Record<number, string[]>, timeElapsed: number) => {
    if (!activeQuizSession) return;

    const { quiz, questions } = activeQuizSession;

    // Calculate score
    let totalScore = 0;
    let maxScore = 0;
    let correctCount = 0;
    let partialCount = 0;
    let wrongCount = 0;
    let unansweredCount = 0;

    questions.forEach((q) => {
      maxScore += q.positivePoints;
      const selected = userAnswers[q.id] || [];
      const correctNorm = q.correctAnswers.map((a) => a.trim().toLowerCase());
      const selectedNorm = selected.map((s) => s.trim().toLowerCase());

      if (selectedNorm.length === 0) {
        unansweredCount++;
      } else if (q.type === 'TRUE_FALSE') {
        const trueKeys = ['vrai', 'v', 'a', 'true'];
        const falseKeys = ['faux', 'f', 'b', 'false'];
        const userIsTrue = selectedNorm.some((k) => trueKeys.includes(k));
        const userIsFalse = selectedNorm.some((k) => falseKeys.includes(k));
        const correctIsTrue = correctNorm.some((k) => trueKeys.includes(k));
        const correctIsFalse = correctNorm.some((k) => falseKeys.includes(k));

        if ((userIsTrue && correctIsTrue) || (userIsFalse && correctIsFalse)) {
          correctCount++;
          totalScore += q.positivePoints;
        } else {
          wrongCount++;
          totalScore -= q.negativePoints;
        }
      } else {
        const correctMatches = selectedNorm.filter((k) => correctNorm.includes(k)).length;
        const wrongMatches = selectedNorm.filter((k) => !correctNorm.includes(k)).length;

        if (wrongMatches > 0) {
          wrongCount++;
          if (q.negativePoints > 0) totalScore -= q.negativePoints;
        } else if (correctMatches === correctNorm.length && correctNorm.length > 0) {
          correctCount++;
          totalScore += q.positivePoints;
        } else if (correctMatches > 0 && correctNorm.length > 1) {
          partialCount++;
          totalScore += q.positivePoints / 2;
        } else {
          wrongCount++;
        }
      }
    });

    const newAttempt: QuizAttempt = {
      id: Date.now().toString(),
      quizId: quiz.id,
      quizTitle: quiz.title,
      score: Math.max(0, Math.round(totalScore * 10) / 10),
      maxScore,
      correctCount,
      partialCount,
      wrongCount,
      unansweredCount,
      timeTakenSeconds: timeElapsed,
      completedAt: Date.now(),
      userAnswers,
    };

    setAttempts((prev) => [newAttempt, ...prev]);

    setActiveResult({
      quiz,
      questions,
      userAnswers,
      timeElapsed,
    });
    setActiveQuizSession(null);
  };

  // Handler: create custom quiz
  const handleSaveQuiz = (newQuiz: Quiz, questions: Question[]) => {
    setQuizzes((prev) => [newQuiz, ...prev]);
    setQuestionsMap((prev) => ({
      ...prev,
      [newQuiz.id]: questions,
    }));
    setActiveTab(2); // Jump to Quiz tab
  };

  const handleDeleteQuiz = (quizId: number) => {
    setQuizzes((prev) => prev.filter((q) => q.id !== quizId));
    setQuestionsMap((prev) => {
      const copy = { ...prev };
      delete copy[quizId];
      return copy;
    });
  };

  const handleClearHistory = () => {
    setAttempts([]);
  };

  const handleDeleteAttempt = (attemptId: string) => {
    setAttempts((prev) => prev.filter((a) => a.id !== attemptId));
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 flex flex-col font-sans">
      {/* 1. If currently in Active Quiz Playing Mode */}
      {activeQuizSession ? (
        <QuizPlayScreen
          quiz={activeQuizSession.quiz}
          questions={activeQuizSession.questions}
          isPracticeMode={activeQuizSession.isPractice}
          onFinish={handleFinishQuiz}
          onQuit={() => setActiveQuizSession(null)}
        />
      ) : activeResult ? (
        /* 2. If viewing Quiz Result */
        <QuizResultScreen
          quiz={activeResult.quiz}
          questions={activeResult.questions}
          userAnswers={activeResult.userAnswers}
          timeElapsedSeconds={activeResult.timeElapsed}
          onRestart={() => handleStartQuiz(activeResult.quiz, false)}
          onHome={() => {
            setActiveResult(null);
            setActiveTab(0);
          }}
          onOpenCourses={() => {
            setActiveResult(null);
            setActiveTab(1);
          }}
          onOpenHistory={() => setShowHistory(true)}
        />
      ) : selectedCourse ? (
        /* 3. If reading a specific course */
        <CourseDetailScreen
          course={selectedCourse}
          onBack={() => setSelectedCourse(null)}
          onStartQuiz={handleStartQuizById}
          onOpenCalculators={() => setShowCalculators(true)}
        />
      ) : (
        /* 4. Main App Shell with Header, Tab Views & Bottom Navigation */
        <>
          <Header
            onOpenHistory={() => setShowHistory(true)}
            onOpenDoctor={() => setActiveTab(4)}
            onOpenCalculators={() => setShowCalculators(true)}
            attemptCount={attempts.length}
          />

          <main className="flex-1 max-w-4xl mx-auto w-full px-4 pt-4 sm:pt-6">
            {activeTab === 0 && (
              <HomeScreen
                courses={courses}
                quizzes={quizzes}
                onSelectCourse={(course) => setSelectedCourse(course)}
                onSelectQuiz={handleStartQuiz}
                onOpenCalculators={() => setShowCalculators(true)}
                onOpenHistory={() => setShowHistory(true)}
                onNavigateTab={(tab) => {
                  setSelectedCourse(null);
                  setActiveTab(tab);
                }}
              />
            )}

            {activeTab === 1 && (
              <CoursesScreen
                courses={courses}
                onSelectCourse={(course) => setSelectedCourse(course)}
                onStartQuiz={handleStartQuizById}
                onOpenCalculators={() => setShowCalculators(true)}
              />
            )}

            {activeTab === 2 && (
              <QuizListScreen
                quizzes={quizzes}
                onSelectQuiz={handleStartQuiz}
                onOpenCreateQuiz={() => setShowQuizEditor(true)}
                onDeleteQuiz={handleDeleteQuiz}
              />
            )}

            {activeTab === 3 && (
              <FlashcardsScreen
                onStartCourse={(subject) => {
                  const c = courses.find((item) => item.subject === subject);
                  if (c) setSelectedCourse(c);
                  else setActiveTab(1);
                }}
                onNavigateTab={(tab) => {
                  setSelectedCourse(null);
                  setActiveTab(tab);
                }}
              />
            )}

            {activeTab === 4 && (
              <DoctorDetailScreen
                onBack={() => setActiveTab(0)}
                onStartExam={(quiz) => handleStartQuiz(quiz, false)}
                featuredQuiz={quizzes.find((q) => q.id === 50) || quizzes[0]}
              />
            )}
          </main>

          <BottomNav
            currentTab={activeTab}
            onTabChange={(tab) => {
              setSelectedCourse(null);
              setActiveTab(tab);
            }}
            coursesCount={courses.length}
            quizzesCount={quizzes.length}
          />
        </>
      )}

      {/* Global Modals */}
      <CalculatorsModal
        isOpen={showCalculators}
        onClose={() => setShowCalculators(false)}
      />

      <HistoryModal
        isOpen={showHistory}
        onClose={() => setShowHistory(false)}
        attempts={attempts}
        onClearHistory={handleClearHistory}
        onDeleteAttempt={handleDeleteAttempt}
        onReplay={handleStartQuizById}
      />

      <QuizEditorModal
        isOpen={showQuizEditor}
        onClose={() => setShowQuizEditor(false)}
        onSaveQuiz={handleSaveQuiz}
      />
    </div>
  );
}

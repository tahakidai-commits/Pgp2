import React, { useState, useMemo } from 'react';
import { 
  Trophy, 
  RotateCcw, 
  Home, 
  BookOpen, 
  History, 
  Check, 
  X, 
  HelpCircle, 
  Lightbulb, 
  ChevronRight,
  Clock
} from 'lucide-react';
import { Question, Quiz } from '../types';

interface QuizResultScreenProps {
  quiz: Quiz;
  questions: Question[];
  userAnswers: Record<number, string[]>;
  timeElapsedSeconds: number;
  onRestart: () => void;
  onHome: () => void;
  onOpenCourses: () => void;
  onOpenHistory: () => void;
}

export const QuizResultScreen: React.FC<QuizResultScreenProps> = ({
  quiz,
  questions,
  userAnswers,
  timeElapsedSeconds,
  onRestart,
  onHome,
  onOpenCourses,
  onOpenHistory,
}) => {
  const [filter, setFilter] = useState<'all' | 'wrong' | 'correct' | 'unanswered'>('all');

  // Calculate detailed summary
  const summary = useMemo(() => {
    let totalScore = 0;
    let maxScore = 0;
    let correctCount = 0;
    let partialCount = 0;
    let wrongCount = 0;
    let unansweredCount = 0;

    const questionResults = questions.map((q) => {
      const selected = userAnswers[q.id] || [];
      const correctNorm = q.correctAnswers.map((a) => a.trim().toLowerCase());
      const selectedNorm = selected.map((s) => s.trim().toLowerCase());

      maxScore += q.positivePoints;
      let points = 0;
      let isFully = false;
      let isPartial = false;
      let isWrong = false;
      let isUnanswered = false;

      if (selectedNorm.length === 0) {
        isUnanswered = true;
        unansweredCount++;
        points = 0;
      } else if (q.type === 'TRUE_FALSE') {
        const trueKeys = ['vrai', 'v', 'a', 'true'];
        const falseKeys = ['faux', 'f', 'b', 'false'];
        const userIsTrue = selectedNorm.some((k) => trueKeys.includes(k));
        const userIsFalse = selectedNorm.some((k) => falseKeys.includes(k));
        const correctIsTrue = correctNorm.some((k) => trueKeys.includes(k));
        const correctIsFalse = correctNorm.some((k) => falseKeys.includes(k));

        const isExact = (userIsTrue && correctIsTrue) || (userIsFalse && correctIsFalse);
        if (isExact) {
          isFully = true;
          correctCount++;
          points = q.positivePoints;
        } else {
          isWrong = true;
          wrongCount++;
          points = -q.negativePoints;
        }
      } else {
        const correctMatches = selectedNorm.filter((k) => correctNorm.includes(k)).length;
        const wrongMatches = selectedNorm.filter((k) => !correctNorm.includes(k)).length;

        if (wrongMatches > 0) {
          isWrong = true;
          wrongCount++;
          points = q.negativePoints > 0 ? -q.negativePoints : 0;
        } else if (correctMatches === correctNorm.length && correctNorm.length > 0) {
          isFully = true;
          correctCount++;
          points = q.positivePoints;
        } else if (correctMatches > 0 && correctNorm.length > 1) {
          isPartial = true;
          partialCount++;
          points = q.positivePoints / 2;
        } else {
          isWrong = true;
          wrongCount++;
          points = 0;
        }
      }

      totalScore += points;

      return {
        question: q,
        selected,
        points,
        isFully,
        isPartial,
        isWrong,
        isUnanswered,
      };
    });

    const percentage = maxScore > 0 ? Math.max(0, Math.round((totalScore / maxScore) * 100)) : 0;

    return {
      totalScore: Math.round(totalScore * 10) / 10,
      maxScore,
      percentage,
      correctCount,
      partialCount,
      wrongCount,
      unansweredCount,
      questionResults,
    };
  }, [questions, userAnswers]);

  const filteredResults = useMemo(() => {
    return summary.questionResults.filter((r) => {
      if (filter === 'wrong') return r.isWrong;
      if (filter === 'correct') return r.isFully || r.isPartial;
      if (filter === 'unanswered') return r.isUnanswered;
      return true;
    });
  }, [summary, filter]);

  const minutes = Math.floor(timeElapsedSeconds / 60);
  const seconds = timeElapsedSeconds % 60;

  return (
    <div className="min-h-screen bg-slate-50 pb-28">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-4 py-3 sticky top-0 z-20">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <button
            onClick={onHome}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-slate-900 cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span>Accueil</span>
          </button>
          <span className="text-xs font-bold text-slate-900">Bilan & Corrigé Officiel</span>
          <button
            onClick={onOpenHistory}
            className="flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-700 cursor-pointer"
          >
            <History className="w-4 h-4" />
            <span>Historique</span>
          </button>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 pt-6 space-y-6">
        {/* Score Trophy Card */}
        <div className="bg-linear-to-br from-blue-600 via-blue-700 to-indigo-800 rounded-3xl p-6 text-white text-center shadow-lg relative overflow-hidden space-y-3">
          <div className="w-16 h-16 rounded-full bg-white/20 border-2 border-white/30 backdrop-blur-md flex items-center justify-center mx-auto shadow-inner">
            <Trophy className="w-8 h-8 text-amber-300" />
          </div>

          <div>
            <span className="px-3 py-0.5 rounded-full text-[11px] font-extrabold uppercase bg-white/20 text-blue-100">
              {quiz.title}
            </span>
            <h2 className="text-3xl sm:text-4xl font-black mt-2">
              {summary.totalScore} <span className="text-xl font-bold text-blue-200">/ {summary.maxScore} pts</span>
            </h2>
          </div>

          <div className="flex items-center justify-center gap-3 pt-1">
            <div className="px-3 py-1 rounded-full bg-white/15 backdrop-blur-xs font-black text-sm text-white">
              {summary.percentage}% de réussite
            </div>
            <div className="flex items-center gap-1 text-xs font-bold text-blue-100 px-3 py-1 rounded-full bg-white/15">
              <Clock className="w-3.5 h-3.5" />
              <span>{minutes}m {seconds < 10 ? `0${seconds}` : seconds}s</span>
            </div>
          </div>
        </div>

        {/* Breakdown Stats Grid */}
        <div className="grid grid-cols-4 gap-2">
          <div className="bg-white p-3 rounded-2xl border border-slate-200 text-center shadow-xs">
            <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto mb-1">
              <Check className="w-4 h-4" />
            </div>
            <div className="text-lg font-black text-emerald-600">{summary.correctCount}</div>
            <div className="text-[10px] font-bold text-slate-500">Exactes</div>
          </div>

          <div className="bg-white p-3 rounded-2xl border border-slate-200 text-center shadow-xs">
            <div className="w-7 h-7 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mx-auto mb-1">
              <Check className="w-4 h-4" />
            </div>
            <div className="text-lg font-black text-amber-600">{summary.partialCount}</div>
            <div className="text-[10px] font-bold text-slate-500">Partielles</div>
          </div>

          <div className="bg-white p-3 rounded-2xl border border-slate-200 text-center shadow-xs">
            <div className="w-7 h-7 rounded-full bg-red-100 text-red-700 flex items-center justify-center mx-auto mb-1">
              <X className="w-4 h-4" />
            </div>
            <div className="text-lg font-black text-red-600">{summary.wrongCount}</div>
            <div className="text-[10px] font-bold text-slate-500">Erreurs</div>
          </div>

          <div className="bg-white p-3 rounded-2xl border border-slate-200 text-center shadow-xs">
            <div className="w-7 h-7 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center mx-auto mb-1">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div className="text-lg font-black text-slate-600">{summary.unansweredCount}</div>
            <div className="text-[10px] font-bold text-slate-500">Non rép.</div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2">
          <button
            onClick={onRestart}
            className="flex-1 py-3 px-4 rounded-2xl border border-slate-300 bg-white hover:bg-slate-50 font-bold text-xs text-slate-800 transition-colors flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
          >
            <RotateCcw className="w-4 h-4 text-blue-600" />
            <span>Rejouer ce quiz</span>
          </button>
          <button
            onClick={onOpenCourses}
            className="flex-1 py-3 px-4 rounded-2xl bg-teal-600 hover:bg-teal-700 font-bold text-xs text-white transition-colors flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
          >
            <BookOpen className="w-4 h-4" />
            <span>Réviser le cours</span>
          </button>
        </div>

        {/* Corrigé Header & Filters */}
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">
              Corrigé Détaillé des Questions
            </h3>
            <span className="text-xs text-slate-500 font-medium">
              {filteredResults.length} affichée(s)
            </span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 rounded-full text-xs font-bold transition-colors cursor-pointer ${
                filter === 'all'
                  ? 'bg-slate-900 text-white'
                  : 'bg-white text-slate-600 border border-slate-200'
              }`}
            >
              Toutes ({summary.questionResults.length})
            </button>
            <button
              onClick={() => setFilter('wrong')}
              className={`px-3 py-1.5 rounded-full text-xs font-bold transition-colors cursor-pointer ${
                filter === 'wrong'
                  ? 'bg-red-600 text-white'
                  : 'bg-white text-red-700 border border-red-200'
              }`}
            >
              Erreurs ({summary.wrongCount})
            </button>
            <button
              onClick={() => setFilter('correct')}
              className={`px-3 py-1.5 rounded-full text-xs font-bold transition-colors cursor-pointer ${
                filter === 'correct'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-white text-emerald-700 border border-emerald-200'
              }`}
            >
              Réussies ({summary.correctCount + summary.partialCount})
            </button>
            <button
              onClick={() => setFilter('unanswered')}
              className={`px-3 py-1.5 rounded-full text-xs font-bold transition-colors cursor-pointer ${
                filter === 'unanswered'
                  ? 'bg-slate-700 text-white'
                  : 'bg-white text-slate-600 border border-slate-200'
              }`}
            >
              Sans réponse ({summary.unansweredCount})
            </button>
          </div>
        </div>

        {/* Detailed Questions List */}
        <div className="space-y-3">
          {filteredResults.map((item) => {
            const q = item.question;
            const borderStyle = item.isFully
              ? 'border-emerald-300'
              : item.isPartial
              ? 'border-amber-300'
              : item.isWrong
              ? 'border-red-300'
              : 'border-slate-200';

            return (
              <div
                key={q.id}
                className={`bg-white rounded-3xl p-5 border-2 shadow-xs space-y-3 ${borderStyle}`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-800">
                    Question {q.questionIndex}
                  </span>
                  <span
                    className={`text-xs font-black px-2.5 py-0.5 rounded-full ${
                      item.points > 0
                        ? 'bg-emerald-100 text-emerald-800'
                        : item.points < 0
                        ? 'bg-red-100 text-red-800'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {item.points > 0 ? `+${item.points} pt` : `${item.points} pt`}
                  </span>
                </div>

                <p className="text-sm font-bold text-slate-900 leading-snug">
                  {q.questionText}
                </p>

                {/* Answers recap */}
                <div className="p-3 bg-slate-50 rounded-2xl text-xs space-y-1.5 border border-slate-200/70">
                  <div className="flex items-start gap-1">
                    <span className="text-slate-500 font-semibold shrink-0">Votre réponse :</span>
                    <span
                      className={`font-black ${
                        item.isFully
                          ? 'text-emerald-700'
                          : item.isPartial
                          ? 'text-amber-700'
                          : 'text-red-700'
                      }`}
                    >
                      {item.selected.length > 0 ? item.selected.join(', ') : 'Aucune réponse'}
                    </span>
                  </div>
                  <div className="flex items-start gap-1">
                    <span className="text-slate-500 font-semibold shrink-0">Corrigé officiel :</span>
                    <span className="font-black text-emerald-800">
                      {q.correctAnswers.join(', ')}
                    </span>
                  </div>
                </div>

                {/* Official Explanation / Justification */}
                {q.explanation && (
                  <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-2xl text-xs text-blue-950 flex items-start gap-2">
                    <Lightbulb className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <p className="leading-relaxed">{q.explanation}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

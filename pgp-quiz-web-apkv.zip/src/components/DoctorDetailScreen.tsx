import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Heart, 
  Star, 
  MapPin, 
  Calendar, 
  Clock, 
  ChevronRight, 
  CheckCircle2, 
  Sparkles,
  Phone,
  Mail,
  GraduationCap
} from 'lucide-react';
import { Quiz } from '../types';

interface DoctorDetailScreenProps {
  onBack: () => void;
  onStartExam: (quiz: Quiz) => void;
  featuredQuiz?: Quiz;
}

export const DoctorDetailScreen: React.FC<DoctorDetailScreenProps> = ({
  onBack,
  onStartExam,
  featuredQuiz,
}) => {
  const [isFavorite, setIsFavorite] = useState(false);
  const [selectedTab, setSelectedTab] = useState<'about' | 'reviews' | 'availability'>('about');
  const [selectedDateIndex, setSelectedDateIndex] = useState(1);
  const [selectedTimeIndex, setSelectedTimeIndex] = useState(1);
  const [showBookedConfirm, setShowBookedConfirm] = useState(false);

  const dates = [
    { day: 'Lun', num: '21' },
    { day: 'Mar', num: '22' },
    { day: 'Mer', num: '23' },
    { day: 'Jeu', num: '24' },
    { day: 'Ven', num: '25' },
    { day: 'Sam', num: '26' },
  ];

  const timeSlots = ['08:00', '09:00', '10:00', '11:00', '14:00', '15:00'];

  return (
    <div className="min-h-screen bg-slate-50 pb-28">
      {/* Top Banner Image with Overlay */}
      <div className="relative h-64 sm:h-72 w-full bg-slate-900 overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=800&q=80"
          alt="Dr. Kouassi Alain"
          className="w-full h-full object-cover opacity-85"
        />
        <div className="absolute inset-0 bg-linear-to-t from-slate-950 via-slate-900/40 to-transparent"></div>

        {/* Top Floating Actions */}
        <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-md text-slate-800 flex items-center justify-center shadow-md transition-colors hover:bg-white cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <button
            onClick={() => setIsFavorite(!isFavorite)}
            className={`w-10 h-10 rounded-full bg-white/90 backdrop-blur-md flex items-center justify-center shadow-md transition-colors hover:bg-white cursor-pointer ${
              isFavorite ? 'text-red-500' : 'text-slate-700'
            }`}
          >
            <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
          </button>
        </div>

        {/* Doctor Name Overlay */}
        <div className="absolute bottom-5 left-6 right-6 text-white space-y-1">
          <span className="px-2.5 py-0.5 rounded-full bg-blue-500/80 backdrop-blur-md text-[11px] font-bold uppercase tracking-wider">
            Encadrement Pédagogique
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold leading-tight">
            Dr. Kouassi Alain
          </h1>
          <p className="text-xs sm:text-sm text-blue-100 font-medium">
            Médecin généraliste & Responsable Évaluations PGP1
          </p>
        </div>
      </div>

      {/* Main Card with rounded top */}
      <div className="max-w-3xl mx-auto px-4 -mt-4 relative z-10 space-y-5">
        <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-sm space-y-5">
          {/* Rating and Location Row */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div className="flex items-center gap-1.5">
              <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
              <span className="text-sm font-bold text-slate-900">4.8</span>
              <span className="text-xs text-slate-500">(124 avis étudiants)</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium">
              <MapPin className="w-4 h-4 text-blue-600 shrink-0" />
              <span>CHU de Cocody, Abidjan</span>
            </div>
          </div>

          {/* Tab Selector */}
          <div className="flex border-b border-slate-200 gap-4 text-xs font-bold">
            <button
              onClick={() => setSelectedTab('about')}
              className={`pb-2.5 transition-colors cursor-pointer ${
                selectedTab === 'about'
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              À propos
            </button>
            <button
              onClick={() => setSelectedTab('reviews')}
              className={`pb-2.5 transition-colors cursor-pointer ${
                selectedTab === 'reviews'
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Avis étudiants
            </button>
            <button
              onClick={() => setSelectedTab('availability')}
              className={`pb-2.5 transition-colors cursor-pointer ${
                selectedTab === 'availability'
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Disponibilités
            </button>
          </div>

          {/* Tab Content */}
          <div className="text-xs sm:text-sm text-slate-700 leading-relaxed min-h-[70px]">
            {selectedTab === 'about' && (
              <p>
                Le Dr. Kouassi Alain est enseignant-chercheur et praticien hospitalier au CHU de Cocody. Spécialiste de la prise en charge clinique et toxicologique, il coordonne les travaux dirigés de Toxicologie et d'Opérations Galéniques pour les étudiants de la faculté de médecine et de pharmacie.
              </p>
            )}
            {selectedTab === 'reviews' && (
              <div className="space-y-2">
                <blockquote className="p-3 bg-slate-50 rounded-2xl border border-slate-200/80 italic text-xs text-slate-700">
                  "Excellentes séances de révision PGP1 ! Ses explications sur le métabolisme du méthanol et la CAT lors des intoxications au monoxyde de carbone sont limpides."
                </blockquote>
                <div className="text-[11px] font-bold text-slate-500 text-right">
                  — Étudiante PGP1 (Septembre 2026)
                </div>
              </div>
            )}
            {selectedTab === 'availability' && (
              <p>
                Disponible du lundi au vendredi de 08:00 à 16:00 pour des séances individuelles ou en petits groupes de préparation aux examens finaux PGP1.
              </p>
            )}
          </div>

          {/* Date Picker */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">Choisir une date de tutorat</h3>
              <span className="text-xs font-bold text-blue-600">Septembre 2026</span>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
              {dates.map((d, idx) => {
                const isSelected = selectedDateIndex === idx;
                return (
                  <button
                    key={idx}
                    onClick={() => setSelectedDateIndex(idx)}
                    className={`w-14 h-16 rounded-2xl flex flex-col items-center justify-center transition-all cursor-pointer shrink-0 ${
                      isSelected
                        ? 'bg-blue-600 text-white shadow-md'
                        : 'bg-slate-50 text-slate-700 border border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <span className={`text-[10px] font-semibold ${isSelected ? 'text-blue-100' : 'text-slate-500'}`}>
                      {d.day}
                    </span>
                    <span className="text-base font-extrabold">{d.num}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Time Slots */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-900">Créneaux horaires disponibles</h3>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {timeSlots.map((time, idx) => {
                const isSelected = selectedTimeIndex === idx;
                return (
                  <button
                    key={idx}
                    onClick={() => setSelectedTimeIndex(idx)}
                    className={`py-2 px-1 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
                      isSelected
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-slate-50 text-slate-700 border border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {time}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="space-y-2">
          <button
            onClick={() => {
              setShowBookedConfirm(true);
              if (featuredQuiz) {
                setTimeout(() => {
                  onStartExam(featuredQuiz);
                }, 1200);
              }
            }}
            className="w-full py-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <GraduationCap className="w-5 h-5" />
            <span>Confirmer le tutorat & Lancer l'évaluation</span>
          </button>
        </div>
      </div>

      {/* Confirmation Toast */}
      {showBookedConfirm && (
        <div className="fixed bottom-20 left-4 right-4 max-w-sm mx-auto z-50 p-4 rounded-2xl bg-emerald-600 text-white text-xs font-bold shadow-xl flex items-center gap-3 animate-bounce">
          <CheckCircle2 className="w-5 h-5 shrink-0" />
          <span>Créneau réservé avec le Dr. Kouassi Alain ! Lancement de l'épreuve...</span>
        </div>
      )}
    </div>
  );
};

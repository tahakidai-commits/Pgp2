import React, { useState, useMemo } from 'react';
import { X, Calculator, Droplet, ArrowRight, ShieldCheck, Info } from 'lucide-react';

interface CalculatorsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CalculatorsModal: React.FC<CalculatorsModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'perfusion' | 'dilution' | 'dosage' | 'memos'>('perfusion');

  // Perfusion state
  const [perfVol, setPerfVol] = useState('2000');
  const [perfTime, setPerfTime] = useState('20');
  const [perfTimeType, setPerfTimeType] = useState<'hours' | 'minutes'>('hours');
  const [perfDropFactor, setPerfDropFactor] = useState('20'); // 20 drops = 1 mL standard

  const perfResult = useMemo(() => {
    const v = parseFloat(perfVol);
    const t = parseFloat(perfTime);
    const factor = parseFloat(perfDropFactor) || 20;
    if (isNaN(v) || isNaN(t) || v <= 0 || t <= 0) return null;
    const totalMin = perfTimeType === 'hours' ? t * 60 : t;
    const totalDrops = v * factor;
    const rate = Math.round(totalDrops / totalMin);
    return {
      rate,
      totalDrops,
      totalMin,
    };
  }, [perfVol, perfTime, perfTimeType, perfDropFactor]);

  // Dilution state: C1 * V1 = C2 * V2
  const [dilC1, setDilC1] = useState('5'); // g/L
  const [dilC2, setDilC2] = useState('0.5'); // g/L desired
  const [dilV2, setDilV2] = useState('100'); // mL desired

  const dilResult = useMemo(() => {
    const c1 = parseFloat(dilC1);
    const c2 = parseFloat(dilC2);
    const v2 = parseFloat(dilV2);
    if (isNaN(c1) || isNaN(c2) || isNaN(v2) || c1 <= 0 || c2 <= 0 || v2 <= 0 || c2 > c1) {
      return null;
    }
    const v1 = (c2 * v2) / c1; // Volume de solution mère à prélever
    const vWater = v2 - v1; // Volume d'eau à ajouter pour faire V2
    return {
      v1: Math.round(v1 * 100) / 100,
      vWater: Math.round(vWater * 100) / 100,
    };
  }, [dilC1, dilC2, dilV2]);

  // Pediatric Dosage state
  const [doseMgPerKg, setDoseMgPerKg] = useState('50');
  const [weightKg, setWeightKg] = useState('60');
  const [doseTakes, setDoseTakes] = useState('3');
  const [pillDoseMg, setPillDoseMg] = useState('500');

  const dosageResult = useMemo(() => {
    const mgKg = parseFloat(doseMgPerKg);
    const w = parseFloat(weightKg);
    const takes = parseInt(doseTakes) || 1;
    const pill = parseFloat(pillDoseMg) || 500;
    if (isNaN(mgKg) || isNaN(w) || mgKg <= 0 || w <= 0) return null;
    const totalDailyMg = mgKg * w;
    const totalDailyG = totalDailyMg / 1000;
    const mgPerTake = totalDailyMg / takes;
    const pillsPerTake = mgPerTake / pill;
    return {
      totalDailyMg,
      totalDailyG,
      mgPerTake,
      pillsPerTake: Math.round(pillsPerTake * 10) / 10,
    };
  }, [doseMgPerKg, weightKg, doseTakes, pillDoseMg]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-teal-500 text-white flex items-center justify-center shadow-xs">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 leading-tight">
                Calculateurs Galéniques & Posologies
              </h2>
              <p className="text-xs text-slate-500">Outils de calcul conforme au cours PGP1</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-200 hover:bg-slate-300 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-200 bg-white px-4 pt-2 gap-1 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('perfusion')}
            className={`py-2 px-3 text-xs font-bold rounded-t-xl transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'perfusion'
                ? 'bg-teal-50 text-teal-700 border-b-2 border-teal-600'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Débit de Perfusion
          </button>
          <button
            onClick={() => setActiveTab('dilution')}
            className={`py-2 px-3 text-xs font-bold rounded-t-xl transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'dilution'
                ? 'bg-teal-50 text-teal-700 border-b-2 border-teal-600'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Dilutions (C1V1)
          </button>
          <button
            onClick={() => setActiveTab('dosage')}
            className={`py-2 px-3 text-xs font-bold rounded-t-xl transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'dosage'
                ? 'bg-teal-50 text-teal-700 border-b-2 border-teal-600'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Doses & Posologies
          </button>
          <button
            onClick={() => setActiveTab('memos')}
            className={`py-2 px-3 text-xs font-bold rounded-t-xl transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'memos'
                ? 'bg-teal-50 text-teal-700 border-b-2 border-teal-600'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Cuillères & Gouttes
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          {/* TAB 1: PERFUSION */}
          {activeTab === 'perfusion' && (
            <div className="space-y-4">
              <div className="p-3 bg-teal-50 border border-teal-200 rounded-2xl text-xs text-teal-900 flex items-start gap-2">
                <Info className="w-4 h-4 text-teal-700 shrink-0 mt-0.5" />
                <span>
                  Formule officielle : <strong>Débit (gttes/min) = (Volume en mL × Tubulure) ÷ Durée en min</strong>.
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700">Volume à perfuser (mL)</label>
                  <input
                    type="number"
                    value={perfVol}
                    onChange={(e) => setPerfVol(e.target.value)}
                    className="w-full mt-1 px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900 focus:bg-white"
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-bold text-slate-700">Durée prescrite</label>
                    <div className="flex gap-1 text-[10px]">
                      <button
                        onClick={() => setPerfTimeType('hours')}
                        className={`px-1.5 py-0.5 rounded font-bold ${
                          perfTimeType === 'hours' ? 'bg-teal-600 text-white' : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        Heures
                      </button>
                      <button
                        onClick={() => setPerfTimeType('minutes')}
                        className={`px-1.5 py-0.5 rounded font-bold ${
                          perfTimeType === 'minutes' ? 'bg-teal-600 text-white' : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        Min
                      </button>
                    </div>
                  </div>
                  <input
                    type="number"
                    value={perfTime}
                    onChange={(e) => setPerfTime(e.target.value)}
                    className="w-full mt-1 px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700">Type de tubulure de perfusion</label>
                <select
                  value={perfDropFactor}
                  onChange={(e) => setPerfDropFactor(e.target.value)}
                  className="w-full mt-1 px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                >
                  <option value="20">Standard adulte : 1 mL = 20 gouttes</option>
                  <option value="60">Micro-gouttes pédiatrie : 1 mL = 60 micro-gouttes</option>
                  <option value="15">Transfusion sang total : 1 mL = 15 gouttes</option>
                </select>
              </div>

              {perfResult && (
                <div className="p-4 bg-linear-to-br from-teal-500 to-teal-700 text-white rounded-2xl shadow-sm space-y-1">
                  <div className="text-xs text-teal-100 font-medium">Débit calculé à régler :</div>
                  <div className="text-3xl font-black">
                    {perfResult.rate} <span className="text-sm font-bold text-teal-100">gouttes / minute</span>
                  </div>
                  <div className="text-xs text-teal-100 pt-1 border-t border-teal-400/40 flex justify-between">
                    <span>Total gouttes : {perfResult.totalDrops.toLocaleString()}</span>
                    <span>Durée totale : {perfResult.totalMin} minutes</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: DILUTION */}
          {activeTab === 'dilution' && (
            <div className="space-y-4">
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-2xl text-xs text-blue-900 flex items-start gap-2">
                <Info className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
                <span>
                  Loi de conservation : <strong>C₁ × V₁ = C₂ × V₂</strong> (pour préparer un volume V₂ à concentration C₂ à partir d’une solution mère C₁).
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700">Concentration Mère (C₁)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={dilC1}
                    onChange={(e) => setDilC1(e.target.value)}
                    placeholder="ex: 5 g/L"
                    className="w-full mt-1 px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700">Concentration Fille (C₂)</label>
                  <input
                    type="number"
                    step="0.05"
                    value={dilC2}
                    onChange={(e) => setDilC2(e.target.value)}
                    placeholder="ex: 0.5 g/L"
                    className="w-full mt-1 px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700">Volume Fille voulu (V₂ en mL)</label>
                  <input
                    type="number"
                    value={dilV2}
                    onChange={(e) => setDilV2(e.target.value)}
                    placeholder="ex: 100 mL"
                    className="w-full mt-1 px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900"
                  />
                </div>
              </div>

              {dilResult && (
                <div className="p-4 bg-linear-to-br from-blue-600 to-indigo-700 text-white rounded-2xl shadow-sm space-y-2">
                  <div className="text-xs text-blue-100 font-medium">Mode opératoire de préparation :</div>
                  <div className="text-xl font-bold flex items-center gap-2">
                    <span>Prélever</span>
                    <span className="text-2xl font-black text-amber-300">{dilResult.v1} mL</span>
                    <span>de solution mère</span>
                  </div>
                  <div className="text-xs text-blue-100">
                    Compléter avec <strong>{dilResult.vWater} mL</strong> d'eau distillée pour obtenir un volume final de <strong>{dilV2} mL</strong>.
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: DOSAGE */}
          {activeTab === 'dosage' && (
            <div className="space-y-4">
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl text-xs text-amber-900 flex items-start gap-2">
                <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <span>
                  Exemple officiel du cours (p. 51) : <strong>Aspirine 50 mg/kg/j</strong> pour un adulte de 60 kg en 3 prises par jour.
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700">Posologie (mg / kg / jour)</label>
                  <input
                    type="number"
                    value={doseMgPerKg}
                    onChange={(e) => setDoseMgPerKg(e.target.value)}
                    className="w-full mt-1 px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700">Poids du patient (kg)</label>
                  <input
                    type="number"
                    value={weightKg}
                    onChange={(e) => setWeightKg(e.target.value)}
                    className="w-full mt-1 px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700">Nombre de prises par jour</label>
                  <input
                    type="number"
                    value={doseTakes}
                    onChange={(e) => setDoseTakes(e.target.value)}
                    className="w-full mt-1 px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700">Dosage du comprimé (mg)</label>
                  <input
                    type="number"
                    value={pillDoseMg}
                    onChange={(e) => setPillDoseMg(e.target.value)}
                    className="w-full mt-1 px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-900"
                  />
                </div>
              </div>

              {dosageResult && (
                <div className="p-4 bg-linear-to-br from-amber-500 to-amber-700 text-white rounded-2xl shadow-sm space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-amber-100">Dose journalière totale :</span>
                    <span className="text-xl font-black">
                      {dosageResult.totalDailyMg} mg ({dosageResult.totalDailyG} g/j)
                    </span>
                  </div>
                  <div className="flex justify-between items-center border-t border-amber-400/40 pt-2">
                    <span className="text-xs text-amber-100">Par prise ({doseTakes} prises/j) :</span>
                    <span className="text-lg font-bold">
                      {dosageResult.mgPerTake} mg = <strong className="text-xl text-amber-200">{dosageResult.pillsPerTake} cp</strong>
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: MEMOS */}
          {activeTab === 'memos' && (
            <div className="space-y-3">
              <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50 space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Contenance des cuillères médicales (Pharmacopée) :
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                  <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                    <div className="font-bold text-slate-900">Cuillère à café (c à c)</div>
                    <div className="text-teal-700 font-extrabold text-sm">5 mL</div>
                    <div className="text-[11px] text-slate-500">5g eau, 4.5g huile, 6.5g sirop</div>
                  </div>
                  <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                    <div className="font-bold text-slate-900">Cuillère à dessert (c à d)</div>
                    <div className="text-teal-700 font-extrabold text-sm">10 mL</div>
                    <div className="text-[11px] text-slate-500">10g eau, 9g huile, 13g sirop</div>
                  </div>
                  <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                    <div className="font-bold text-slate-900">Cuillère à soupe (c à s)</div>
                    <div className="text-teal-700 font-extrabold text-sm">15 mL</div>
                    <div className="text-[11px] text-slate-500">15g eau, 13.5g huile, 19g sirop</div>
                  </div>
                </div>
              </div>

              <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50 space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Compte-gouttes normalisé à 20°C :
                </h4>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-white p-3 rounded-xl border border-slate-200">
                    <span className="text-slate-500 block text-[11px]">Eau distillée</span>
                    <span className="text-base font-extrabold text-blue-700">20 gouttes = 1 mL (1 g)</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200">
                    <span className="text-slate-500 block text-[11px]">Solutions alcooliques</span>
                    <span className="text-base font-extrabold text-indigo-700">40 gouttes = 1 g</span>
                  </div>
                </div>
              </div>

              <div className="border border-slate-200 rounded-2xl p-4 bg-emerald-50 text-xs text-emerald-950 space-y-1">
                <div className="font-bold text-emerald-900">Formule SRO OMS pour 1 Litre :</div>
                <div>• NaCl : <strong>3,5 g</strong></div>
                <div>• KCl : <strong>1,5 g</strong></div>
                <div>• Citrate trisodique dihydraté : <strong>2,9 g</strong></div>
                <div>• Glucose anhydre : <strong>20,0 g</strong></div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50/50 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs transition-colors cursor-pointer"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};

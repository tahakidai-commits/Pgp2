import React, { useState, useMemo } from 'react';
import { 
  X, 
  History, 
  Trash2, 
  Trophy, 
  Play, 
  Clock, 
  BarChart2, 
  CheckCircle2, 
  AlertTriangle 
} from 'lucide-react';
import { QuizAttempt } from '../types';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  attempts: QuizAttempt[];
  onClearHistory: () => void;
  onDeleteAttempt: (id: string) => void;
  onReplay: (quizId: number) => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  isOpen,
  onClose,
  attempts,
  onClearHistory,
  onDeleteAttempt,
  onReplay,
}) => {
  const [filter, setFilter] = useState<'all' | 'high' | 'mid' | 'low'>('all');
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const stats = useMemo(() => {
    if (attempts.length === 0) return { avg: 0, totalMinutes: 0 };
    const valid = attempts.filter((a) => a.maxScore > 0);
    const sumPct = valid.reduce((acc, a) => acc + (a.score / a.maxScore) * 100, 0);
    const avg = valid.length > 0 ? Math.round(sumPct / valid.length) : 0;
    const totalSeconds = attempts.reduce((acc, a) => acc + a.timeTakenSeconds, 0);
    return {
      avg,
      totalMinutes: Math.round(totalSeconds / 60),
    };
  }, [attempts]);

  const filteredAttempts = useMemo(() => {
    return attempts.filter((a) => {
      const pct = a.maxScore > 0 ? (a.score / a.maxScore) * 100 : 0;
      if (filter === 'high') return pct >= 80;
      if (filter === 'mid') return pct >= 50 && pct < 80;
      if (filter === 'low') return pct < 50;
      return true;
    });
  }, [attempts, filter]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 leading-tight">
                Historique des Évaluations
              </h2>
              <p className="text-xs text-slate-500">Progression et résultats sauvegardés</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {attempts.length > 0 && (
              <button
                onClick={() => setShowClearConfirm(true)}
                className="w-8 h-8 rounded-full bg-red-50 hover:bg-red-100 text-red-600 flex items-center justify-center transition-colors cursor-pointer"
                title="Tout effacer"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-200 hover:bg-slate-300 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          {attempts.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <div className="w-16 h-16 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
                <Trophy className="w-8 h-8 text-blue-400" />
              </div>
              <h3 className="text-base font-bold text-slate-900">Aucun quiz terminé</h3>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                Passez votre premier quiz ou entraînement pour enregistrer votre score et suivre vos progrès.
              </p>
            </div>
          ) : (
            <>
              {/* Stats Hero Card */}
              <div className="bg-linear-to-r from-blue-600 to-indigo-700 rounded-2xl p-4 text-white flex items-center justify-around text-center shadow-xs">
                <div>
                  <div className="text-2xl font-black">{attempts.length}</div>
                  <div className="text-[11px] text-blue-100 font-semibold">Quiz passés</div>
                </div>
                <div className="w-px h-8 bg-white/20"></div>
                <div>
                  <div className="text-2xl font-black">{stats.avg}%</div>
                  <div className="text-[11px] text-blue-100 font-semibold">Moyenne générale</div>
                </div>
                <div className="w-px h-8 bg-white/20"></div>
                <div>
                  <div className="text-2xl font-black">{stats.totalMinutes}m</div>
                  <div className="text-[11px] text-blue-100 font-semibold">Temps d'étude</div>
                </div>
              </div>

              {/* Filter Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                <button
                  onClick={() => setFilter('all')}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold transition-colors cursor-pointer ${
                    filter === 'all'
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  Tous ({attempts.length})
                </button>
                <button
                  onClick={() => setFilter('high')}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold transition-colors cursor-pointer ${
                    filter === 'high'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                  }`}
                >
                  ≥ 80% Réussis
                </button>
                <button
                  onClick={() => setFilter('mid')}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold transition-colors cursor-pointer ${
                    filter === 'mid'
                      ? 'bg-amber-600 text-white'
                      : 'bg-amber-50 text-amber-700 border border-amber-200'
                  }`}
                >
                  50% - 79%
                </button>
                <button
                  onClick={() => setFilter('low')}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold transition-colors cursor-pointer ${
                    filter === 'low'
                      ? 'bg-red-600 text-white'
                      : 'bg-red-50 text-red-700 border border-red-200'
                  }`}
                >
                  &lt; 50% À revoir
                </button>
              </div>

              {/* Attempts List */}
              <div className="space-y-2.5">
                {filteredAttempts.map((attempt) => {
                  const pct =
                    attempt.maxScore > 0
                      ? Math.round((attempt.score / attempt.maxScore) * 100)
                      : 0;
                  const dateStr = new Date(attempt.completedAt).toLocaleDateString('fr-FR', {
                    day: 'numeric',
                    month: 'short',
                    hour: '2-digit',
                    minute: '2-digit',
                  });

                  return (
                    <div
                      key={attempt.id}
                      className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-12 h-12 rounded-xl flex items-center justify-center font-black text-sm shrink-0 ${
                            pct >= 80
                              ? 'bg-emerald-100 text-emerald-700'
                              : pct >= 50
                              ? 'bg-amber-100 text-amber-700'
                              : 'bg-red-100 text-red-700'
                          }`}
                        >
                          {pct}%
                        </div>
                        <div>
                          <h4 className="text-xs sm:text-sm font-bold text-slate-900 line-clamp-1">
                            {attempt.quizTitle}
                          </h4>
                          <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                            <span>Score: {attempt.score} / {attempt.maxScore}</span>
                            <span>•</span>
                            <span className="flex items-center gap-0.5">
                              <Clock className="w-3 h-3" />
                              {Math.floor(attempt.timeTakenSeconds / 60)}m {attempt.timeTakenSeconds % 60}s
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-400 block mt-0.5">
                            {dateStr}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          onClick={() => {
                            onClose();
                            onReplay(attempt.quizId);
                          }}
                          className="px-3 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          <Play className="w-3 h-3 fill-current" />
                          <span>Rejouer</span>
                        </button>
                        <button
                          onClick={() => onDeleteAttempt(attempt.id)}
                          className="w-7 h-7 rounded-lg text-slate-400 hover:text-red-600 flex items-center justify-center transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>

        {/* Clear Confirmation Dialog */}
        {showClearConfirm && (
          <div className="p-4 bg-red-50 border-t border-red-200 text-center space-y-2">
            <p className="text-xs font-bold text-red-900">
              Voulez-vous vraiment effacer tout votre historique de scores ?
            </p>
            <div className="flex justify-center gap-2">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="px-3 py-1 rounded-xl bg-white border border-slate-300 text-xs font-bold text-slate-700"
              >
                Annuler
              </button>
              <button
                onClick={() => {
                  onClearHistory();
                  setShowClearConfirm(false);
                }}
                className="px-3 py-1 rounded-xl bg-red-600 text-white text-xs font-bold"
              >
                Confirmer l'effacement
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

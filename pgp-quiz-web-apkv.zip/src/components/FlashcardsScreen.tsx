import React, { useState, useMemo, useEffect, useCallback } from 'react';
import {
  Layers,
  RotateCw,
  CheckCircle2,
  XCircle,
  Shuffle,
  Search,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Lightbulb,
  Award,
  Plus,
  BookOpen,
  Filter,
  Check,
  AlertCircle,
  X,
  Trash2,
  Bug,
  Pill,
  Activity,
  Package,
  HeartHandshake
} from 'lucide-react';
import { Flashcard, FlashcardSubject } from '../types';
import { INITIAL_FLASHCARDS } from '../data/flashcardsData';

interface FlashcardsScreenProps {
  onStartCourse?: (subject: string) => void;
  onNavigateTab?: (tab: number) => void;
}

export const FlashcardsScreen: React.FC<FlashcardsScreenProps> = ({
  onStartCourse,
  onNavigateTab,
}) => {
  // 1. Persistent custom flashcards
  const [cards, setCards] = useState<Flashcard[]>(() => {
    try {
      const saved = localStorage.getItem('pgp_custom_flashcards');
      if (saved) {
        const custom: Flashcard[] = JSON.parse(saved);
        return [...INITIAL_FLASHCARDS, ...custom];
      }
    } catch (e) {
      console.error(e);
    }
    return INITIAL_FLASHCARDS;
  });

  // 2. Persistent Leitner progress
  // map cardId -> { status: 'new' | 'learning' | 'mastered', reviewCount: number }
  const [progressMap, setProgressMap] = useState<Record<string, 'new' | 'learning' | 'mastered'>>(() => {
    try {
      const saved = localStorage.getItem('pgp_flashcards_progress');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return {};
  });

  // Filters & mode
  const [selectedSubject, setSelectedSubject] = useState<string>('Tous');
  const [viewMode, setViewMode] = useState<'study' | 'list'>('study');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [showMnemonic, setShowMnemonic] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);

  // New card form state
  const [newSubject, setNewSubject] = useState<FlashcardSubject>('Parasitologie');
  const [newCategory, setNewCategory] = useState('');
  const [newFront, setNewFront] = useState('');
  const [newBack, setNewBack] = useState('');
  const [newMnemonic, setNewMnemonic] = useState('');
  const [newRef, setNewRef] = useState('');

  // Persist progress
  useEffect(() => {
    try {
      localStorage.setItem('pgp_flashcards_progress', JSON.stringify(progressMap));
    } catch (e) {
      console.error(e);
    }
  }, [progressMap]);

  // Persist custom cards
  const saveCustomCards = (updatedCards: Flashcard[]) => {
    setCards(updatedCards);
    try {
      const customOnly = updatedCards.filter((c) => c.isCustom);
      localStorage.setItem('pgp_custom_flashcards', JSON.stringify(customOnly));
    } catch (e) {
      console.error(e);
    }
  };

  // Filtered cards
  const filteredCards = useMemo(() => {
    return cards.filter((card) => {
      const matchesSub = selectedSubject === 'Tous' || card.subject === selectedSubject;
      const matchesSearch =
        searchQuery.trim() === '' ||
        card.front.toLowerCase().includes(searchQuery.toLowerCase()) ||
        card.back.toLowerCase().includes(searchQuery.toLowerCase()) ||
        card.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (card.mnemonic && card.mnemonic.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesSub && matchesSearch;
    });
  }, [cards, selectedSubject, searchQuery]);

  // Reset index when filter changes
  useEffect(() => {
    setCurrentIndex(0);
    setIsFlipped(false);
    setShowMnemonic(false);
  }, [selectedSubject]);

  const currentCard = filteredCards[currentIndex] || filteredCards[0];

  // Progression counters
  const totalDeck = filteredCards.length;
  const masteredCount = useMemo(() => {
    return filteredCards.filter((c) => progressMap[c.id] === 'mastered').length;
  }, [filteredCards, progressMap]);
  const learningCount = useMemo(() => {
    return filteredCards.filter((c) => progressMap[c.id] === 'learning').length;
  }, [filteredCards, progressMap]);
  const newCount = totalDeck - masteredCount - learningCount;
  const masteryPercentage = totalDeck > 0 ? Math.round((masteredCount / totalDeck) * 100) : 0;

  // Handlers for rating card
  const handleRateCard = (rating: 'learning' | 'mastered') => {
    if (!currentCard) return;

    setProgressMap((prev) => ({
      ...prev,
      [currentCard.id]: rating,
    }));

    // Transition to next card
    if (currentIndex < filteredCards.length - 1) {
      setIsFlipped(false);
      setShowMnemonic(false);
      setTimeout(() => {
        setCurrentIndex((i) => i + 1);
      }, 150);
    } else {
      // Reached the end of deck
      setIsFlipped(false);
      setShowMnemonic(false);
    }
  };

  const handleNext = () => {
    if (currentIndex < filteredCards.length - 1) {
      setIsFlipped(false);
      setShowMnemonic(false);
      setCurrentIndex((i) => i + 1);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setIsFlipped(false);
      setShowMnemonic(false);
      setCurrentIndex((i) => i - 1);
    }
  };

  const handleShuffle = () => {
    setIsFlipped(false);
    setShowMnemonic(false);
    setCards((prev) => [...prev].sort(() => Math.random() - 0.5));
    setCurrentIndex(0);
  };

  const handleResetProgress = () => {
    if (window.confirm('Voulez-vous réinitialiser votre progression de mémorisation pour ces fiches ?')) {
      setProgressMap((prev) => {
        const copy = { ...prev };
        filteredCards.forEach((c) => {
          delete copy[c.id];
        });
        return copy;
      });
      setCurrentIndex(0);
      setIsFlipped(false);
    }
  };

  // Keyboard navigation
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (viewMode !== 'study' || showAddModal) return;
      if (e.code === 'Space') {
        e.preventDefault();
        setIsFlipped((f) => !f);
      } else if (e.code === 'ArrowRight') {
        handleNext();
      } else if (e.code === 'ArrowLeft') {
        handlePrev();
      } else if (e.key === '1') {
        handleRateCard('learning');
      } else if (e.key === '2' || e.key === '3') {
        handleRateCard('mastered');
      }
    },
    [viewMode, showAddModal, currentIndex, filteredCards.length, currentCard]
  );

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  // Subject icon helper
  const getSubjectBadge = (subject: FlashcardSubject) => {
    switch (subject) {
      case 'Parasitologie':
        return {
          bg: 'bg-rose-100 text-rose-700 border-rose-200',
          icon: Bug,
          color: 'text-rose-600',
        };
      case 'Galénique':
        return {
          bg: 'bg-amber-100 text-amber-800 border-amber-200',
          icon: Pill,
          color: 'text-amber-600',
        };
      case 'Toxicologie':
        return {
          bg: 'bg-sky-100 text-sky-800 border-sky-200',
          icon: Activity,
          color: 'text-sky-600',
        };
      case 'Pharmacologie':
        return {
          bg: 'bg-indigo-100 text-indigo-800 border-indigo-200',
          icon: Sparkles,
          color: 'text-indigo-600',
        };
      case 'Gestion Logistique':
        return {
          bg: 'bg-teal-100 text-teal-800 border-teal-200',
          icon: Package,
          color: 'text-teal-600',
        };
      default:
        return {
          bg: 'bg-slate-100 text-slate-800 border-slate-200',
          icon: BookOpen,
          color: 'text-slate-600',
        };
    }
  };

  // Add card submit
  const handleAddCardSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFront.trim() || !newBack.trim()) return;

    const newCard: Flashcard = {
      id: `fc-custom-${Date.now()}`,
      subject: newSubject,
      category: newCategory.trim() || 'Personnalisé',
      front: newFront.trim(),
      back: newBack.trim(),
      mnemonic: newMnemonic.trim() || undefined,
      sourceReference: newRef.trim() || 'Fiche personnelle PGP1',
      difficulty: 'Moyen',
      isCustom: true,
    };

    saveCustomCards([newCard, ...cards]);
    setNewFront('');
    setNewBack('');
    setNewMnemonic('');
    setNewRef('');
    setShowAddModal(false);
  };

  const handleDeleteCard = (cardId: string) => {
    if (window.confirm('Supprimer cette flashcard personnalisée ?')) {
      saveCustomCards(cards.filter((c) => c.id !== cardId));
    }
  };

  return (
    <div className="space-y-6 pb-28">
      {/* 1. Header Banner */}
      <div className="bg-gradient-to-r from-indigo-700 via-purple-700 to-rose-700 rounded-3xl p-5 sm:p-7 text-white shadow-lg relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-10 pointer-events-none flex items-center justify-end pr-6">
          <Layers className="w-56 h-56" />
        </div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 backdrop-blur-md text-xs font-bold uppercase tracking-wider text-rose-200 mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              Mémorisation Active & Répétition Espacée
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
              Flashcards PGP1
            </h2>
            <p className="text-xs sm:text-sm text-indigo-100/90 mt-1 max-w-xl">
              Maîtrisez les notions clés, pièges de concours, cycles parasitaires, posologies exactes et formules galéniques grâce à la méthode de rappel actif.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowAddModal(true)}
              className="px-4 py-2.5 rounded-2xl bg-white text-indigo-900 font-bold text-xs shadow-md hover:bg-indigo-50 transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4 text-indigo-600" />
              <span>Créer une carte</span>
            </button>

            <button
              onClick={handleShuffle}
              title="Mélanger le paquet"
              className="p-2.5 rounded-2xl bg-white/15 backdrop-blur-md text-white hover:bg-white/25 transition-all cursor-pointer shrink-0"
            >
              <Shuffle className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Live Progress Stats Bar */}
        <div className="mt-5 pt-4 border-t border-white/15 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-2.5">
            <div className="text-[11px] font-semibold text-indigo-200 uppercase tracking-wider">Total fiches</div>
            <div className="text-xl font-black mt-0.5">{totalDeck}</div>
          </div>
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-2.5">
            <div className="text-[11px] font-semibold text-emerald-300 uppercase tracking-wider">Maîtrisées</div>
            <div className="text-xl font-black mt-0.5 text-emerald-300">{masteredCount}</div>
          </div>
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-2.5">
            <div className="text-[11px] font-semibold text-amber-300 uppercase tracking-wider">À revoir</div>
            <div className="text-xl font-black mt-0.5 text-amber-300">{learningCount}</div>
          </div>
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-2.5">
            <div className="text-[11px] font-semibold text-indigo-200 uppercase tracking-wider">Taux de rétention</div>
            <div className="text-xl font-black mt-0.5 text-white">{masteryPercentage}%</div>
          </div>
        </div>
      </div>

      {/* 2. Navigation & Subject Filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Subject Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {['Tous', 'Parasitologie', 'Galénique', 'Toxicologie', 'Pharmacologie', 'Gestion Logistique'].map((subj) => (
            <button
              key={subj}
              onClick={() => setSelectedSubject(subj)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all shrink-0 cursor-pointer ${
                selectedSubject === subj
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200/80 hover:bg-slate-100'
              }`}
            >
              {subj}
            </button>
          ))}
        </div>

        {/* View mode toggle (Study vs List) */}
        <div className="flex items-center bg-white p-1 rounded-2xl border border-slate-200/80 shadow-xs shrink-0 self-start sm:self-auto">
          <button
            onClick={() => setViewMode('study')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              viewMode === 'study' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Mode Cartes</span>
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              viewMode === 'list' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Toutes les fiches</span>
          </button>
        </div>
      </div>

      {/* 3. STUDY MODE: Interactive Flip Card */}
      {viewMode === 'study' && (
        <div className="space-y-4">
          {filteredCards.length === 0 ? (
            <div className="bg-white rounded-3xl p-10 text-center border border-slate-200 text-slate-500">
              <Layers className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-800">Aucune flashcard trouvée</h3>
              <p className="text-xs text-slate-500 mt-1">Sélectionnez une autre matière ou créez votre première carte personnalisée.</p>
            </div>
          ) : (
            <>
              {/* Progress counter & actions */}
              <div className="flex items-center justify-between px-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-700 bg-white px-3 py-1 rounded-full border border-slate-200/80 shadow-2xs">
                    Carte {currentIndex + 1} / {totalDeck}
                  </span>
                  {progressMap[currentCard.id] === 'mastered' && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      Maîtrisée
                    </span>
                  )}
                  {progressMap[currentCard.id] === 'learning' && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800">
                      <AlertCircle className="w-3 h-3 text-amber-600" />
                      À revoir
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleResetProgress}
                    className="text-xs text-slate-500 hover:text-slate-800 underline font-medium cursor-pointer"
                  >
                    Réinitialiser
                  </button>
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-indigo-600 h-full transition-all duration-300 rounded-full"
                  style={{ width: `${((currentIndex + 1) / totalDeck) * 100}%` }}
                />
              </div>

              {/* 3D Flip Card Container */}
              <div
                onClick={() => setIsFlipped((f) => !f)}
                className="perspective-1000 min-h-[380px] sm:min-h-[420px] w-full cursor-pointer select-none"
              >
                <div
                  className={`w-full min-h-[380px] sm:min-h-[420px] relative transition-transform duration-500 transform-style-preserve-3d ${
                    isFlipped ? 'rotate-y-180' : ''
                  }`}
                >
                  {/* FRONT SIDE */}
                  <div className="absolute inset-0 w-full h-full bg-white rounded-3xl p-6 sm:p-8 border-2 border-slate-200/90 shadow-md hover:border-indigo-300 transition-all flex flex-col justify-between backface-hidden">
                    <div>
                      {/* Subject and Category badge */}
                      <div className="flex items-center justify-between gap-2 mb-4">
                        <div className="flex items-center gap-2">
                          {(() => {
                            const badge = getSubjectBadge(currentCard.subject);
                            const Icon = badge.icon;
                            return (
                              <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${badge.bg}`}>
                                <Icon className={`w-3.5 h-3.5 ${badge.color}`} />
                                {currentCard.subject}
                              </span>
                            );
                          })()}
                          <span className="text-xs font-semibold text-slate-500 bg-slate-100 px-2.5 py-0.5 rounded-full">
                            {currentCard.category}
                          </span>
                        </div>

                        {currentCard.sourceReference && (
                          <span className="text-[11px] font-medium text-slate-400 hidden sm:inline-block">
                            {currentCard.sourceReference}
                          </span>
                        )}
                      </div>

                      {/* Question / Prompt */}
                      <div className="pt-6 sm:pt-10">
                        <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 mb-2 block">
                          Question / Notion clé :
                        </span>
                        <h3 className="text-lg sm:text-2xl font-black text-slate-900 leading-snug">
                          {currentCard.front}
                        </h3>
                      </div>
                    </div>

                    {/* Hint / Flip call to action */}
                    <div className="pt-6 border-t border-slate-100 flex items-center justify-between text-slate-400">
                      <div className="flex items-center gap-1.5 text-xs text-slate-500">
                        <Lightbulb className="w-4 h-4 text-amber-500" />
                        <span>Cliquez sur la carte ou appuyez sur Espace pour retourner</span>
                      </div>
                      <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center hover:bg-slate-200 transition-colors">
                        <RotateCw className="w-4 h-4" />
                      </div>
                    </div>
                  </div>

                  {/* BACK SIDE */}
                  <div className="absolute inset-0 w-full h-full bg-gradient-to-b from-indigo-50/70 via-white to-white rounded-3xl p-6 sm:p-8 border-2 border-indigo-300 shadow-xl flex flex-col justify-between backface-hidden rotate-y-180 overflow-y-auto">
                    <div>
                      {/* Top Header on Back */}
                      <div className="flex items-center justify-between gap-2 mb-3">
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-indigo-100 text-indigo-800 border border-indigo-200">
                          <Check className="w-3.5 h-3.5 text-indigo-600" />
                          Réponse & Corrigé détaillé
                        </span>

                        {currentCard.sourceReference && (
                          <span className="text-[11px] font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-200">
                            {currentCard.sourceReference}
                          </span>
                        )}
                      </div>

                      {/* Answer content */}
                      <div className="text-sm sm:text-base text-slate-800 leading-relaxed font-medium whitespace-pre-line py-2">
                        {currentCard.back}
                      </div>

                      {/* Mnemonic tip if present */}
                      {currentCard.mnemonic && (
                        <div className="mt-4 p-3 rounded-2xl bg-amber-50 border border-amber-200/90 flex items-start gap-2.5">
                          <Lightbulb className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                          <div>
                            <span className="text-xs font-bold text-amber-800 uppercase tracking-wider block">
                              Moyen mnémotechnique / Règle d'or :
                            </span>
                            <p className="text-xs font-semibold text-amber-900 mt-0.5">
                              {currentCard.mnemonic}
                            </p>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Bottom CTA on back */}
                    <div className="pt-4 border-t border-indigo-100 flex items-center justify-between text-xs text-indigo-600 font-semibold">
                      <span>Évaluez votre rétention ci-dessous :</span>
                      <span className="text-slate-400">Cliquez pour revenir</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 4. Action Buttons: Leitner rating & navigation */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
                <button
                  onClick={handlePrev}
                  disabled={currentIndex === 0}
                  className={`p-3 rounded-2xl font-bold text-xs border flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    currentIndex === 0
                      ? 'opacity-40 cursor-not-allowed bg-slate-100 text-slate-400 border-slate-200'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Précédente</span>
                </button>

                <button
                  onClick={() => handleRateCard('learning')}
                  className="p-3 rounded-2xl font-bold text-xs bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                >
                  <XCircle className="w-4 h-4 text-rose-600" />
                  <span>À revoir (Touche 1)</span>
                </button>

                <button
                  onClick={() => handleRateCard('mastered')}
                  className="p-3 rounded-2xl font-bold text-xs bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100 transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Bien su ! (Touche 2)</span>
                </button>

                <button
                  onClick={handleNext}
                  disabled={currentIndex === filteredCards.length - 1}
                  className={`p-3 rounded-2xl font-bold text-xs border flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    currentIndex === filteredCards.length - 1
                      ? 'opacity-40 cursor-not-allowed bg-slate-100 text-slate-400 border-slate-200'
                      : 'bg-indigo-600 text-white border-indigo-600 hover:bg-indigo-700 shadow-sm'
                  }`}
                >
                  <span>Suivante</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Keyboard shortcuts reminder */}
              <div className="text-center pt-1 text-[11px] text-slate-400 font-medium">
                Astuce clavier : <span className="bg-slate-200 px-1.5 py-0.5 rounded font-bold text-slate-600">Espace</span> pour retourner • <span className="bg-slate-200 px-1.5 py-0.5 rounded font-bold text-slate-600">←</span> <span className="bg-slate-200 px-1.5 py-0.5 rounded font-bold text-slate-600">→</span> pour naviguer • <span className="bg-slate-200 px-1.5 py-0.5 rounded font-bold text-slate-600">1</span> À revoir • <span className="bg-slate-200 px-1.5 py-0.5 rounded font-bold text-slate-600">2</span> Maîtrisé
              </div>
            </>
          )}
        </div>
      )}

      {/* 4. LIST MODE: Browse all Flashcards */}
      {viewMode === 'list' && (
        <div className="space-y-4">
          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher une notion, un médicament, un parasite, une formule..."
              className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white border border-slate-200/80 text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 shadow-2xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {filteredCards.map((card, idx) => {
              const badge = getSubjectBadge(card.subject);
              const Icon = badge.icon;
              const isMastered = progressMap[card.id] === 'mastered';
              const isLearning = progressMap[card.id] === 'learning';

              return (
                <div
                  key={card.id}
                  className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${badge.bg}`}>
                        <Icon className={`w-3 h-3 ${badge.color}`} />
                        {card.subject}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                          {card.category}
                        </span>
                        {card.isCustom && (
                          <button
                            onClick={() => handleDeleteCard(card.id)}
                            title="Supprimer la carte personnalisée"
                            className="text-rose-500 hover:text-rose-700 p-1"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    <h4 className="text-sm font-bold text-slate-900 mt-2 leading-snug">
                      {card.front}
                    </h4>

                    <div className="mt-3 p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs text-slate-700 whitespace-pre-line leading-relaxed font-medium">
                      {card.back}
                    </div>

                    {card.mnemonic && (
                      <div className="mt-2.5 p-2 rounded-xl bg-amber-50 border border-amber-200/70 text-[11px] text-amber-900 font-semibold flex items-center gap-1.5">
                        <Lightbulb className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                        <span>{card.mnemonic}</span>
                      </div>
                    )}
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[11px] text-slate-400">
                      {card.sourceReference || 'Support officiel'}
                    </span>
                    <button
                      onClick={() => {
                        const originalIndex = filteredCards.findIndex((c) => c.id === card.id);
                        if (originalIndex !== -1) {
                          setCurrentIndex(originalIndex);
                          setViewMode('study');
                        }
                      }}
                      className="px-3 py-1 rounded-xl text-xs font-bold bg-indigo-50 text-indigo-700 hover:bg-indigo-100 transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <Layers className="w-3 h-3" />
                      <span>Réviser cette carte</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 5. MODAL: Create New Custom Flashcard */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Nouvelle Flashcard PGP1</h3>
                  <p className="text-xs text-slate-500">Ajoutez votre propre fiche de révision mémorisable</p>
                </div>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddCardSubmit} className="space-y-3.5 mt-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Matière *</label>
                  <select
                    value={newSubject}
                    onChange={(e) => setNewSubject(e.target.value as FlashcardSubject)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="Parasitologie">Parasitologie</option>
                    <option value="Galénique">Galénique</option>
                    <option value="Toxicologie">Toxicologie</option>
                    <option value="Pharmacologie">Pharmacologie</option>
                    <option value="Gestion Logistique">Gestion Logistique</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Thème / Chapitre</label>
                  <input
                    type="text"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    placeholder="Ex: Coccidioses, Autoclave..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Question ou Concept (Recto) *
                </label>
                <textarea
                  required
                  rows={2}
                  value={newFront}
                  onChange={(e) => setNewFront(e.target.value)}
                  placeholder="Ex: Quelle est la posologie exacte du praziquantel dans les bilharzioses ?"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Réponse & Explication (Verso) *
                </label>
                <textarea
                  required
                  rows={4}
                  value={newBack}
                  onChange={(e) => setNewBack(e.target.value)}
                  placeholder="Ex: 40 mg/kg en prise unique au cours d'un repas. Actif sur toutes les espèces de schistosomes."
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Moyen mnémotechnique (Optionnel)
                </label>
                <input
                  type="text"
                  value={newMnemonic}
                  onChange={(e) => setNewMnemonic(e.target.value)}
                  placeholder="Ex: 40 mg/kg = dose universelle"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Référence support (Optionnel)
                </label>
                <input
                  type="text"
                  value={newRef}
                  onChange={(e) => setNewRef(e.target.value)}
                  placeholder="Ex: Cours Parasito p. 71"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-indigo-600 text-white hover:bg-indigo-700 shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>Enregistrer la carte</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

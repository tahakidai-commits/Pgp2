import React, { useState, useMemo } from 'react';
import { 
  Search, 
  BookOpen, 
  GraduationCap, 
  Calculator, 
  ChevronRight, 
  FileText, 
  Sparkles, 
  CheckCircle2,
  Clock,
  Layers
} from 'lucide-react';
import { Course } from '../types';

interface CoursesScreenProps {
  courses: Course[];
  onSelectCourse: (course: Course) => void;
  onStartQuiz: (quizId: number) => void;
  onOpenCalculators: () => void;
}

export const CoursesScreen: React.FC<CoursesScreenProps> = ({
  courses,
  onSelectCourse,
  onStartQuiz,
  onOpenCalculators,
}) => {
  const [selectedSubject, setSelectedSubject] = useState<string>('Tous');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const subjects = ['Tous', 'Parasitologie', 'Galénique', 'Toxicologie', 'Gestion Logistique'];

  const filteredCourses = useMemo(() => {
    return courses.filter((c) => {
      const matchesSubject =
        selectedSubject === 'Tous' || c.subject === selectedSubject;
      const matchesSearch =
        searchQuery.trim() === '' ||
        c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.chapters.some((ch) =>
          ch.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          ch.sections.some((s) => s.title.toLowerCase().includes(searchQuery.toLowerCase()))
        );
      return matchesSubject && matchesSearch;
    });
  }, [courses, selectedSubject, searchQuery]);

  return (
    <div className="space-y-6 pb-24">
      {/* Title & Banner */}
      <div className="bg-linear-to-br from-teal-700 via-teal-800 to-slate-900 rounded-3xl p-6 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 max-w-xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 backdrop-blur-md text-xs font-bold text-teal-200 mb-3 border border-white/10">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Fiches & Supports Officiels PGP1</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight mb-2">
            Cours & Fiches de Révision
          </h1>
          <p className="text-xs sm:text-sm text-teal-100/90 leading-relaxed mb-4">
            Consultez les supports complets de cours rédigés selon les programmes officiels : Opérations galéniques, Toxicologie du Pr TIGORI, Logistique des produits de santé et Excipients.
          </p>

          {/* Quick Calculator CTA button */}
          <button
            onClick={onOpenCalculators}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-white text-teal-900 font-bold text-xs sm:text-sm shadow-xs hover:bg-teal-50 transition-colors cursor-pointer"
          >
            <Calculator className="w-4 h-4 text-teal-700" />
            <span>Calculateurs de perfusion & dilutions</span>
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Rechercher un cours, chapitre, notion (ex: lyophilisation, CMM, Paracelse...)"
          className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 text-slate-900 placeholder-slate-400 shadow-xs"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 font-semibold"
          >
            Effacer
          </button>
        )}
      </div>

      {/* Subject Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {subjects.map((sub) => {
          const isSelected = selectedSubject === sub;
          return (
            <button
              key={sub}
              onClick={() => setSelectedSubject(sub)}
              className={`px-4 py-2 rounded-2xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                isSelected
                  ? 'bg-teal-700 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {sub}
            </button>
          );
        })}
      </div>

      {/* Courses List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredCourses.map((course) => {
          const totalSections = course.chapters.reduce(
            (acc, ch) => acc + ch.sections.length,
            0
          );
          return (
            <div
              key={course.id}
              className="bg-white rounded-3xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all overflow-hidden flex flex-col justify-between"
            >
              <div className="p-5">
                {/* Badge row */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span
                    className="px-2.5 py-1 rounded-full text-[11px] font-extrabold uppercase tracking-wider text-white"
                    style={{ backgroundColor: course.colorScheme.primary }}
                  >
                    {course.subject}
                  </span>
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 bg-slate-50 border border-slate-200 px-2.5 py-1 rounded-full">
                    <FileText className="w-3.5 h-3.5 text-slate-400" />
                    <span>{course.badge}</span>
                  </div>
                </div>

                {/* Course Title */}
                <h3 className="text-lg font-bold text-slate-900 mb-1 leading-snug">
                  {course.title}
                </h3>
                <p className="text-xs text-slate-500 font-medium mb-3">
                  {course.author}
                </p>

                {/* Course Summary */}
                <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed mb-4">
                  {course.summary}
                </p>

                {/* Chapters & sections indicator */}
                <div className="flex items-center gap-4 text-xs font-medium text-slate-500 pt-3 border-t border-slate-100">
                  <div className="flex items-center gap-1">
                    <Layers className="w-3.5 h-3.5 text-teal-600" />
                    <span>{course.chapters.length} chapitres</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <BookOpen className="w-3.5 h-3.5 text-blue-600" />
                    <span>{totalSections} notions détaillées</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="px-5 py-3.5 bg-slate-50/70 border-t border-slate-100 flex items-center justify-between gap-2">
                <button
                  onClick={() => onSelectCourse(course)}
                  className="flex-1 py-2 px-3 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Consulter le cours</span>
                </button>

                {course.linkedQuizIds.length > 0 && (
                  <button
                    onClick={() => onStartQuiz(course.linkedQuizIds[0])}
                    className="py-2 px-3 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 text-xs font-bold transition-colors flex items-center justify-center gap-1 cursor-pointer"
                    title="S'entraîner sur les QCM associés"
                  >
                    <GraduationCap className="w-4 h-4" />
                    <span className="hidden sm:inline">Quiz</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {filteredCourses.length === 0 && (
        <div className="text-center py-12 bg-white rounded-3xl border border-slate-200 p-8">
          <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h4 className="text-base font-bold text-slate-800">Aucun cours trouvé</h4>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
            Aucun résultat pour "{searchQuery}". Essayez un autre mot-clé ou réinitialisez les filtres.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedSubject('Tous');
            }}
            className="mt-4 px-4 py-2 rounded-xl bg-teal-600 text-white text-xs font-bold"
          >
            Réinitialiser la recherche
          </button>
        </div>
      )}
    </div>
  );
};

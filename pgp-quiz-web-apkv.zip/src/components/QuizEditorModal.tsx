import React, { useState } from 'react';
import { X, Plus, Trash2, FileText, Check, AlertCircle, Save } from 'lucide-react';
import { Question, QuestionType, Quiz } from '../types';

interface QuizEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveQuiz: (newQuiz: Quiz, questions: Question[]) => void;
}

export const QuizEditorModal: React.FC<QuizEditorModalProps> = ({
  isOpen,
  onClose,
  onSaveQuiz,
}) => {
  const [tab, setTab] = useState<'text' | 'form'>('text');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Mes Cours');
  const [rawText, setRawText] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  // Parser helper matching Android logic
  const parseRawText = (text: string): Question[] => {
    const lines = text.split('\n').map((l) => l.trim()).filter((l) => l.length > 0);
    const parsed: Question[] = [];

    let currentQuestion = '';
    let currentOptions: string[] = [];
    let currentAnswers: string[] = [];
    let currentExplanation = '';
    let qIdx = 1;

    const flush = () => {
      if (currentQuestion.trim().length > 0) {
        let options = currentOptions.length > 0 ? currentOptions : ['VRAI', 'FAUX'];
        const isTrueFalse =
          options.length === 2 &&
          options.some((o) => o.toLowerCase().includes('vrai')) &&
          options.some((o) => o.toLowerCase().includes('faux'));

        const type: QuestionType = isTrueFalse
          ? 'TRUE_FALSE'
          : currentAnswers.length > 1
          ? 'MULTIPLE_CHOICE'
          : 'SINGLE_CHOICE';

        const finalAnswers =
          currentAnswers.length > 0
            ? currentAnswers
            : isTrueFalse
            ? ['VRAI']
            : ['a'];

        parsed.push({
          id: Date.now() + qIdx,
          quizId: 0,
          questionIndex: qIdx++,
          questionText: currentQuestion,
          type,
          options,
          correctAnswers: finalAnswers,
          explanation: currentExplanation || undefined,
          positivePoints: 1.0,
          negativePoints: isTrueFalse ? 0.5 : 0.0,
          maxChoices: finalAnswers.length > 1 ? finalAnswers.length : 1,
        });
      }
      currentQuestion = '';
      currentOptions = [];
      currentAnswers = [];
      currentExplanation = '';
    };

    for (const line of lines) {
      const lower = line.toLowerCase();
      if (/^(\d+[\.\-\)]\s*|Q\s*\d*[\.\:\-]\s*)/i.test(line)) {
        flush();
        currentQuestion = line.replace(/^(\d+[\.\-\)]\s*|Q\s*\d*[\.\:\-]\s*)/i, '').trim();
        if (!currentQuestion) currentQuestion = line;
      } else if (/^[a-eA-E][\)\.\-]\s*/.test(line)) {
        currentOptions.push(line);
      } else if (
        lower.startsWith('réponse:') ||
        lower.startsWith('reponse:') ||
        lower.startsWith('corrigé:') ||
        lower.startsWith('corrige:')
      ) {
        const ans = line.split(':')[1].trim();
        const splitAnswers = ans.split(/[,;\s]+/).filter((a) => a.length > 0);
        currentAnswers.push(...splitAnswers);
      } else if (lower.startsWith('explication:') || lower.startsWith('justification:')) {
        currentExplanation = line.split(':')[1].trim();
      } else if (currentQuestion === '') {
        currentQuestion = line;
      } else {
        if (lower.endsWith('vrai') || lower.endsWith('faux')) {
          const parts = line.split(' ');
          const ans = parts[parts.length - 1].toUpperCase();
          currentAnswers.push(ans);
          currentQuestion += ' ' + parts.slice(0, -1).join(' ');
        } else {
          currentQuestion += ' ' + line;
        }
      }
    }

    flush();
    return parsed;
  };

  const handleSave = () => {
    if (!title.trim()) {
      setError('Veuillez saisir un titre pour le quiz.');
      return;
    }

    const questions = parseRawText(rawText);
    if (questions.length === 0) {
      setError('Veuillez ajouter au moins une question valide.');
      return;
    }

    const newQuiz: Quiz = {
      id: Date.now(),
      title: title.trim(),
      description: description.trim() || `${questions.length} questions personnalisées.`,
      category: category.trim() || 'Mes Quiz',
      isBuiltIn: false,
      questionCount: questions.length,
      createdAt: Date.now(),
    };

    onSaveQuiz(newQuiz, questions);
    onClose();
  };

  const handleInsertSample = () => {
    setRawText(`1. La toxicologie étudie les propriétés toxiques des xénobiotiques.
Réponse: VRAI
Explication: La toxicologie étudie la nocivité des xénobiotiques, tandis que la pharmacologie étudie les effets thérapeutiques.

2. Les matières premières médicamenteuses comprennent :
a- Les principes actifs
b- Les excipients
c- Le conditionnement primaire
d- Les machines de production
Réponse: a, b, c
Explication: Selon l'OMS, les matières premières regroupent les PA, excipients et conditionnements.

3. En Côte d'Ivoire, la LNME est révisée tous les :
a- 2 ans
b- 5 ans
Réponse: a`);
  };

  const detectedQuestions = parseRawText(rawText);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl w-full max-w-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 leading-tight">
                Créer ou Importer un Quiz
              </h2>
              <p className="text-xs text-slate-500">Génération automatique par texte ou questionnaire</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-200 hover:bg-slate-300 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-2xl text-xs text-red-900 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Quiz Details */}
          <div className="space-y-3 bg-slate-50/60 p-4 rounded-2xl border border-slate-200">
            <div>
              <label className="text-xs font-bold text-slate-700">Titre du quiz *</label>
              <input
                type="text"
                value={title}
                onChange={(e) => {
                  setTitle(e.target.value);
                  setError(null);
                }}
                placeholder="ex: Révision Galénique TD 2, Botanique..."
                className="w-full mt-1 px-3 py-2 bg-white border border-slate-300 rounded-xl text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-slate-700">Matière / Catégorie</label>
                <input
                  type="text"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full mt-1 px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-900"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700">Description (facultative)</label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="ex: Entraînement sur les excipients"
                  className="w-full mt-1 px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-900"
                />
              </div>
            </div>
          </div>

          {/* Raw Text Import Field */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800">
                Collez vos questions et corrigés :
              </label>
              <button
                type="button"
                onClick={handleInsertSample}
                className="text-xs font-bold text-blue-600 hover:text-blue-700 cursor-pointer"
              >
                Insérer un exemple type
              </button>
            </div>

            <textarea
              rows={8}
              value={rawText}
              onChange={(e) => {
                setRawText(e.target.value);
                setError(null);
              }}
              placeholder={`1. Votre question ici...\na- Choix 1\nb- Choix 2\nRéponse: a\nExplication: Justification du cours...\n\n2. Question Vrai ou Faux...\nRéponse: VRAI`}
              className="w-full p-3 bg-white border border-slate-300 rounded-2xl text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 leading-relaxed"
            ></textarea>

            <div className="flex items-center justify-between text-xs font-bold pt-1">
              <span
                className={`px-2.5 py-1 rounded-full ${
                  detectedQuestions.length > 0
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-slate-100 text-slate-500'
                }`}
              >
                {detectedQuestions.length} question(s) détectée(s)
              </span>
              <span className="text-slate-400 text-[11px]">Format: numérotation 1. 2. + Réponse:</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-slate-200 bg-slate-50/70 flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-slate-600 hover:text-slate-800 font-bold text-xs"
          >
            Annuler
          </button>
          <button
            onClick={handleSave}
            className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Enregistrer le quiz</span>
          </button>
        </div>
      </div>
    </div>
  );
};

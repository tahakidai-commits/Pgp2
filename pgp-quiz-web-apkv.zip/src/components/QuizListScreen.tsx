import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Play, 
  Plus, 
  Trash2, 
  Clock, 
  CheckCircle2, 
  GraduationCap, 
  Sparkles,
  BookOpen
} from 'lucide-react';
import { Quiz } from '../types';

interface QuizListScreenProps {
  quizzes: Quiz[];
  onSelectQuiz: (quiz: Quiz, practiceMode: boolean) => void;
  onOpenCreateQuiz: () => void;
  onDeleteQuiz?: (quizId: number) => void;
}

export const QuizListScreen: React.FC<QuizListScreenProps> = ({
  quizzes,
  onSelectQuiz,
  onOpenCreateQuiz,
  onDeleteQuiz,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('Tous');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedQuizForMode, setSelectedQuizForMode] = useState<Quiz | null>(null);

  const categories = [
    'Tous',
    'Parasitologie',
    'Pharmacologie',
    'Toxicologie',
    'Gestion Logistique',
    'Matière Première Galénique',
    'Opérations & Calculs Galéniques',
    'Mes Quiz'
  ];

  const filteredQuizzes = useMemo(() => {
    return quizzes.filter((q) => {
      const matchesCat =
        selectedCategory === 'Tous'
          ? true
          : selectedCategory === 'Mes Quiz'
          ? !q.isBuiltIn
          : q.category.toLowerCase() === selectedCategory.toLowerCase();
      const matchesSearch =
        searchQuery.trim() === '' ||
        q.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        q.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        q.category.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCat && matchesSearch;
    });
  }, [quizzes, selectedCategory, searchQuery]);

  return (
    <div className="space-y-6 pb-24">
      {/* Top Banner */}
      <div className="bg-linear-to-r from-blue-600 via-indigo-600 to-purple-700 rounded-3xl p-6 text-white shadow-md flex items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-blue-200">
            Entraînements officiels
          </span>
          <h2 className="text-2xl font-black mt-0.5">Banque de Quiz & Examens</h2>
          <p className="text-xs text-blue-100/90 mt-1 max-w-md">
            Testez vos connaissances en conditions réelles avec le barème officiel ou révisez pas à pas avec corrections immédiates.
          </p>
        </div>
        <button
          onClick={onOpenCreateQuiz}
          className="px-4 py-2.5 rounded-2xl bg-white text-blue-700 font-bold text-xs shadow-xs hover:bg-blue-50 transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Créer un quiz</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Rechercher une épreuve ou un sujet de TD..."
          className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-900 placeholder-slate-400 shadow-xs"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 font-semibold"
          >
            Effacer
          </button>
        )}
      </div>

      {/* Categories Horizontal Filter */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {categories.map((cat) => {
          const isSelected = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-2xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                isSelected
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Quiz List Cards */}
      <div className="space-y-3">
        {filteredQuizzes.map((quiz) => (
          <div
            key={quiz.id}
            className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs hover:shadow-md transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
          >
            <div className="space-y-1.5 max-w-xl">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-700 uppercase tracking-wider">
                  {quiz.category}
                </span>
                <span className="text-[11px] font-semibold text-slate-500 bg-slate-50 border border-slate-200 px-2 py-0.5 rounded-full">
                  {quiz.isBuiltIn ? 'Officiel PGP' : 'Personnalisé'}
                </span>
                <span className="text-[11px] font-bold text-slate-600">
                  {quiz.questionCount} questions
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-900 leading-snug">
                {quiz.title}
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                {quiz.description}
              </p>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
              {!quiz.isBuiltIn && onDeleteQuiz && (
                <button
                  onClick={() => onDeleteQuiz(quiz.id)}
                  title="Supprimer ce quiz"
                  className="w-9 h-9 rounded-2xl bg-red-50 hover:bg-red-100 text-red-600 flex items-center justify-center transition-colors cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={() => setSelectedQuizForMode(quiz)}
                className="px-5 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Lancer le Quiz</span>
              </button>
            </div>
          </div>
        ))}

        {filteredQuizzes.length === 0 && (
          <div className="text-center py-12 bg-white rounded-3xl border border-slate-200 p-8">
            <GraduationCap className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h4 className="text-base font-bold text-slate-800">Aucun quiz trouvé</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
              Aucun quiz ne correspond à votre filtre. Créez votre propre quiz ou choisissez une autre catégorie.
            </p>
            <button
              onClick={onOpenCreateQuiz}
              className="mt-4 px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-bold"
            >
              Créer mon quiz
            </button>
          </div>
        )}
      </div>

      {/* Mode Picker Modal (Révision vs Examen) */}
      {selectedQuizForMode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-slate-200 space-y-4">
            <div className="text-center space-y-1">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-700 uppercase">
                {selectedQuizForMode.category}
              </span>
              <h3 className="text-lg font-bold text-slate-900">
                {selectedQuizForMode.title}
              </h3>
              <p className="text-xs text-slate-500">
                Choisissez le mode d'entraînement :
              </p>
            </div>

            <div className="space-y-2.5">
              {/* Option 1: Révision */}
              <button
                onClick={() => {
                  const q = selectedQuizForMode;
                  setSelectedQuizForMode(null);
                  onSelectQuiz(q, true);
                }}
                className="w-full p-4 rounded-2xl border-2 border-emerald-200 bg-emerald-50/60 hover:bg-emerald-100/70 transition-colors text-left flex items-start gap-3 cursor-pointer"
              >
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-bold text-emerald-950">Mode Révision</div>
                  <div className="text-xs text-emerald-800">
                    Vérification instantanée après chaque question avec justifications détaillées.
                  </div>
                </div>
              </button>

              {/* Option 2: Examen */}
              <button
                onClick={() => {
                  const q = selectedQuizForMode;
                  setSelectedQuizForMode(null);
                  onSelectQuiz(q, false);
                }}
                className="w-full p-4 rounded-2xl border-2 border-blue-200 bg-blue-50/60 hover:bg-blue-100/70 transition-colors text-left flex items-start gap-3 cursor-pointer"
              >
                <Clock className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-bold text-blue-950">Mode Examen</div>
                  <div className="text-xs text-blue-800">
                    Chronomètre 40s par question, barème officiel et résultat final complet.
                  </div>
                </div>
              </button>
            </div>

            <button
              onClick={() => setSelectedQuizForMode(null)}
              className="w-full py-2.5 text-xs font-bold text-slate-500 hover:text-slate-700 transition-colors cursor-pointer"
            >
              Annuler
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  ArrowRight, 
  Check, 
  X, 
  Timer, 
  Pause, 
  Play, 
  RotateCcw, 
  LayoutGrid, 
  Bookmark, 
  BookmarkCheck, 
  Flag, 
  AlertCircle, 
  Lightbulb, 
  CheckCircle2, 
  HelpCircle 
} from 'lucide-react';
import { Question, Quiz } from '../types';

interface QuizPlayScreenProps {
  quiz: Quiz;
  questions: Question[];
  isPracticeMode: boolean;
  onFinish: (
    userAnswers: Record<number, string[]>,
    timeElapsedSeconds: number
  ) => void;
  onQuit: () => void;
}

export const QuizPlayScreen: React.FC<QuizPlayScreenProps> = ({
  quiz,
  questions,
  isPracticeMode,
  onFinish,
  onQuit,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, string[]>>({});
  const [revealedInPractice, setRevealedInPractice] = useState<Record<number, boolean>>({});
  const [bookmarkedQuestions, setBookmarkedQuestions] = useState<Record<number, boolean>>({});
  
  // Timer state (40s countdown per question)
  const [timerSeconds, setTimerSeconds] = useState(40);
  const [isTimerPaused, setIsTimerPaused] = useState(false);
  const [totalTimeElapsed, setTotalTimeElapsed] = useState(0);
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const [showGridModal, setShowGridModal] = useState(false);

  const currentQuestion = questions[currentIndex];
  const selectedOptions = currentQuestion ? userAnswers[currentQuestion.id] || [] : [];
  const isRevealed = currentQuestion ? !!revealedInPractice[currentQuestion.id] : false;
  const isBookmarked = currentQuestion ? !!bookmarkedQuestions[currentQuestion.id] : false;

  // Global & question timer
  useEffect(() => {
    if (isTimerPaused || !currentQuestion) return;

    const interval = setInterval(() => {
      setTotalTimeElapsed((prev) => prev + 1);

      setTimerSeconds((prev) => {
        if (prev <= 1) {
          // Time expired for this question: move to next or finish
          if (currentIndex < questions.length - 1) {
            setCurrentIndex((c) => c + 1);
            return 40;
          } else {
            // Auto finish quiz
            clearInterval(interval);
            onFinish(userAnswers, totalTimeElapsed + 1);
            return 0;
          }
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [currentIndex, isTimerPaused, questions.length, currentQuestion, userAnswers, totalTimeElapsed, onFinish]);

  // Reset 40s timer on question change
  useEffect(() => {
    setTimerSeconds(40);
  }, [currentIndex]);

  if (!currentQuestion) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 text-slate-600 font-bold">
        Chargement des questions...
      </div>
    );
  }

  const handleSelectOption = (key: string) => {
    if (isRevealed && isPracticeMode) return; // Locked once validated in practice

    const qId = currentQuestion.id;
    const isMultiple = currentQuestion.maxChoices > 1 || currentQuestion.type === 'MULTIPLE_CHOICE';

    let newSelection: string[];
    if (isMultiple) {
      if (selectedOptions.includes(key)) {
        newSelection = selectedOptions.filter((k) => k !== key);
      } else {
        newSelection = [...selectedOptions, key];
      }
    } else {
      newSelection = [key];
    }

    setUserAnswers((prev) => ({
      ...prev,
      [qId]: newSelection,
    }));
  };

  const handleValidatePractice = () => {
    setRevealedInPractice((prev) => ({
      ...prev,
      [currentQuestion.id]: true,
    }));
  };

  const handleNext = () => {
    if (currentIndex === questions.length - 1) {
      onFinish(userAnswers, totalTimeElapsed);
    } else {
      setCurrentIndex((prev) => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    }
  };

  // Evaluation of current answer in practice mode
  const normalizedCorrect = currentQuestion.correctAnswers.map((a) => a.trim().toLowerCase());
  const normalizedUser = selectedOptions.map((a) => a.trim().toLowerCase());
  const isFullyCorrect =
    normalizedCorrect.length === normalizedUser.length &&
    normalizedCorrect.every((c) => normalizedUser.includes(c));

  const progressPercent = Math.round(((currentIndex + 1) / questions.length) * 100);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between pb-24">
      {/* Top Bar */}
      <div className="sticky top-0 z-30 bg-white border-b border-slate-200/90 shadow-xs">
        <div className="max-w-3xl mx-auto px-4 py-2.5 flex items-center justify-between">
          <button
            onClick={() => setShowExitConfirm(true)}
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
            title="Quitter le quiz"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          {/* Central progress info */}
          <div className="text-center">
            <span className="text-xs font-bold text-slate-900 block">
              Question {currentIndex + 1} / {questions.length}
            </span>
            <span className="text-[10px] text-slate-500 font-semibold truncate max-w-[200px] inline-block">
              {quiz.title}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() =>
                setBookmarkedQuestions((prev) => ({
                  ...prev,
                  [currentQuestion.id]: !isBookmarked,
                }))
              }
              className={`w-9 h-9 rounded-full flex items-center justify-center transition-colors cursor-pointer ${
                isBookmarked ? 'bg-amber-100 text-amber-600' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
              }`}
              title="Ajouter aux favoris"
            >
              {isBookmarked ? <BookmarkCheck className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
            </button>

            <button
              onClick={() => setShowGridModal(true)}
              className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
              title="Vue d'ensemble des questions"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Progress bar + Timer row */}
        <div className="max-w-3xl mx-auto px-4 pb-2.5 space-y-2">
          {/* Linear bar */}
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden flex items-center">
            <div
              className="bg-blue-600 h-full rounded-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            ></div>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span
              className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                isPracticeMode
                  ? 'bg-emerald-100 text-emerald-800'
                  : 'bg-blue-100 text-blue-800'
              }`}
            >
              {isPracticeMode ? 'Mode Révision' : 'Mode Examen'}
            </span>

            {/* Countdown Badge */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsTimerPaused(!isTimerPaused)}
                className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full font-bold text-xs transition-colors cursor-pointer ${
                  timerSeconds <= 5
                    ? 'bg-red-100 text-red-700 border border-red-300 animate-pulse'
                    : timerSeconds <= 12
                    ? 'bg-amber-100 text-amber-800 border border-amber-300'
                    : 'bg-blue-50 text-blue-700 border border-blue-200'
                }`}
              >
                {isTimerPaused ? <Play className="w-3 h-3" /> : <Timer className="w-3 h-3" />}
                <span>{isTimerPaused ? `Pause (${timerSeconds}s)` : `${timerSeconds}s`}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Card */}
      <div className="max-w-3xl mx-auto px-4 py-4 w-full space-y-4">
        {/* Clinical / Question Context if present */}
        {currentQuestion.contextText && (
          <div className="p-3.5 bg-blue-50/70 border border-blue-200/80 rounded-2xl text-xs text-blue-950 flex items-start gap-2.5 leading-relaxed">
            <AlertCircle className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-[11px] text-blue-800 uppercase tracking-wider mb-0.5">
                Mise en situation / Contexte officiel :
              </div>
              <p>{currentQuestion.contextText}</p>
            </div>
          </div>
        )}

        {/* Question Statement Card */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-xs space-y-3">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 uppercase tracking-wider">
              {quiz.category}
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
              {currentQuestion.type === 'TRUE_FALSE'
                ? 'VRAI / FAUX'
                : currentQuestion.maxChoices > 1
                ? `QCM - ${currentQuestion.maxChoices} réponses`
                : 'Choix unique'}
            </span>
          </div>

          <h2 className="text-base sm:text-lg font-extrabold text-slate-900 leading-snug">
            {currentQuestion.questionText}
          </h2>
        </div>

        {/* Options Group */}
        {currentQuestion.type === 'TRUE_FALSE' ? (
          /* True/False Buttons */
          <div className="grid grid-cols-2 gap-3">
            {['VRAI', 'FAUX'].map((opt) => {
              const isSelected = selectedOptions.some(
                (o) => o.trim().toUpperCase() === opt || (opt === 'VRAI' && (o === 'A' || o === 'V')) || (opt === 'FAUX' && (o === 'B' || o === 'F'))
              );
              const isOptionCorrect = currentQuestion.correctAnswers.some(
                (a) => a.trim().toUpperCase() === opt || (opt === 'VRAI' && (a === 'A' || a === 'V')) || (opt === 'FAUX' && (a === 'B' || a === 'F'))
              );

              let style = 'bg-white border-slate-200 hover:border-slate-300 text-slate-800';
              if (isSelected) {
                style = 'bg-blue-50/50 border-blue-600 text-blue-900 ring-2 ring-blue-600/20';
              }
              if (isRevealed) {
                if (isOptionCorrect) {
                  style = 'bg-emerald-50 border-emerald-500 text-emerald-900 ring-2 ring-emerald-500/30';
                } else if (isSelected && !isOptionCorrect) {
                  style = 'bg-red-50 border-red-500 text-red-900 ring-2 ring-red-500/30';
                }
              }

              return (
                <button
                  key={opt}
                  onClick={() => handleSelectOption(opt)}
                  className={`p-5 rounded-2xl border-2 font-bold text-base sm:text-lg transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs ${style}`}
                >
                  {isRevealed && isOptionCorrect && <Check className="w-5 h-5 text-emerald-600" />}
                  {isRevealed && isSelected && !isOptionCorrect && <X className="w-5 h-5 text-red-600" />}
                  <span>{opt}</span>
                </button>
              );
            })}
          </div>
        ) : (
          /* Multiple Choice / Single Choice Options */
          <div className="space-y-2.5">
            {currentQuestion.options.map((opt, i) => {
              // Extract option key e.g. "a", "b", "c", etc.
              const keyMatch = opt.match(/^([a-eA-E])[\.\-\)]\s*/);
              const optKey = keyMatch ? keyMatch[1].toLowerCase() : String.fromCharCode(97 + i);
              const cleanText = opt.replace(/^[a-eA-E][\.\-\)]\s*/, '');

              const isSelected = selectedOptions.some(
                (o) => o.trim().toLowerCase() === optKey || o.trim().toLowerCase() === opt.trim().toLowerCase()
              );
              const isOptionCorrect = currentQuestion.correctAnswers.some(
                (a) => a.trim().toLowerCase() === optKey || a.trim().toLowerCase() === opt.trim().toLowerCase()
              );

              let cardStyle = 'bg-white border-slate-200 hover:border-slate-300 text-slate-800';
              if (isSelected) {
                cardStyle = 'bg-blue-50/50 border-blue-600 text-blue-950 ring-2 ring-blue-600/20';
              }
              if (isRevealed) {
                if (isOptionCorrect) {
                  cardStyle = 'bg-emerald-50 border-emerald-500 text-emerald-950 ring-2 ring-emerald-500/30';
                } else if (isSelected && !isOptionCorrect) {
                  cardStyle = 'bg-red-50 border-red-500 text-red-950 ring-2 ring-red-500/30';
                }
              }

              return (
                <button
                  key={i}
                  onClick={() => handleSelectOption(optKey)}
                  className={`w-full p-4 rounded-2xl border-2 text-left transition-all flex items-center justify-between gap-3 cursor-pointer shadow-xs ${cardStyle}`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs uppercase shrink-0 ${
                        isRevealed && isOptionCorrect
                          ? 'bg-emerald-500 text-white'
                          : isRevealed && isSelected && !isOptionCorrect
                          ? 'bg-red-500 text-white'
                          : isSelected
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {optKey}
                    </div>
                    <span className="text-xs sm:text-sm font-medium leading-relaxed">
                      {cleanText}
                    </span>
                  </div>

                  <div className="shrink-0">
                    {isRevealed && isOptionCorrect && <Check className="w-5 h-5 text-emerald-600" />}
                    {isRevealed && isSelected && !isOptionCorrect && <X className="w-5 h-5 text-red-600" />}
                  </div>
                </button>
              );
            })}
          </div>
        )}

        {/* Practice Mode Actions & Explanation */}
        {isPracticeMode && (
          <div className="pt-2 space-y-3">
            {!isRevealed ? (
              <button
                onClick={handleValidatePractice}
                disabled={selectedOptions.length === 0}
                className="w-full py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white font-bold text-sm shadow-md transition-all cursor-pointer"
              >
                Vérifier ma réponse
              </button>
            ) : (
              <div className="space-y-3">
                {/* Result Feedback Banner */}
                <div
                  className={`p-4 rounded-2xl border flex items-center gap-3 ${
                    isFullyCorrect
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                      : 'bg-red-50 border-red-300 text-red-950'
                  }`}
                >
                  {isFullyCorrect ? (
                    <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                  ) : (
                    <X className="w-6 h-6 text-red-600 shrink-0" />
                  )}
                  <div>
                    <h4 className="text-sm font-extrabold">
                      {isFullyCorrect ? 'Excellente réponse !' : 'Réponse incorrecte'}
                    </h4>
                    <p className="text-xs">
                      Bonne(s) réponse(s) attendue(s) :{' '}
                      <strong>{currentQuestion.correctAnswers.join(', ')}</strong>
                    </p>
                  </div>
                </div>

                {/* Explanation Card */}
                {currentQuestion.explanation && (
                  <div className="p-4 rounded-2xl bg-blue-50/80 border border-blue-200 text-xs text-blue-950 space-y-1">
                    <div className="flex items-center gap-1.5 font-extrabold text-blue-900 uppercase tracking-wider">
                      <Lightbulb className="w-4 h-4 text-amber-500" />
                      <span>Explication & Corrigé officiel :</span>
                    </div>
                    <p className="leading-relaxed pl-5">{currentQuestion.explanation}</p>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bottom Sticky Navigation */}
      <div className="fixed bottom-0 left-0 right-0 z-20 bg-white border-t border-slate-200 px-4 py-3 shadow-lg">
        <div className="max-w-3xl mx-auto flex items-center justify-between gap-3">
          <button
            onClick={handlePrevious}
            disabled={currentIndex === 0}
            className="px-4 py-2.5 rounded-2xl border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Précédent</span>
          </button>

          <button
            onClick={handleNext}
            className="flex-1 sm:flex-initial px-6 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span>{currentIndex === questions.length - 1 ? 'Terminer l’épreuve' : 'Suivant'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Grid Overview Modal */}
      {showGridModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">
                Vue d’ensemble ({questions.length} questions)
              </h3>
              <button
                onClick={() => setShowGridModal(false)}
                className="w-7 h-7 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-5 gap-2 max-h-60 overflow-y-auto p-1">
              {questions.map((q, idx) => {
                const isAnswered = (userAnswers[q.id] || []).length > 0;
                const isCurrent = idx === currentIndex;
                return (
                  <button
                    key={q.id}
                    onClick={() => {
                      setCurrentIndex(idx);
                      setShowGridModal(false);
                    }}
                    className={`h-11 rounded-xl font-bold text-xs flex items-center justify-center transition-all cursor-pointer ${
                      isCurrent
                        ? 'bg-blue-600 text-white ring-2 ring-blue-300'
                        : isAnswered
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => setShowGridModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
            >
              Fermer la vue d’ensemble
            </button>
          </div>
        </div>
      )}

      {/* Exit Confirmation Dialog */}
      {showExitConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-slate-200 space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Quitter le quiz ?</h3>
              <p className="text-xs text-slate-500 mt-1">
                Votre progression en cours ne sera pas enregistrée si vous quittez maintenant.
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowExitConfirm(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-bold text-xs hover:bg-slate-50 cursor-pointer"
              >
                Continuer
              </button>
              <button
                onClick={onQuit}
                className="flex-1 py-2.5 rounded-xl bg-red-600 text-white font-bold text-xs hover:bg-red-700 cursor-pointer"
              >
                Quitter
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
